import java.io.*;

class advertising
{
  public static void main(String args[])throws IOException
  {
    int cas, swCase, Ccount, freeCount;
    Commercial_ad [] com = null;
    Free_ad [] free = null;
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    while(true)
    {
      System.out.println("1.Commercial_ad\n2.Free_ad\n3.Commercial_ad with cost>3000 display\n4.All free_ads");
      cas=Integer.parseInt(br.readLine());
      switch(cas)
      {
        case 1:
          System.out.println("Enter Number of Commercial Ads - ");
          Ccount=Integer.parseInt(br.readLine());
          com=new Commercial_ad[Ccount];
          for(int i=0;i<Ccount;i++)
          {
            com[i]= new Commercial_ad();
          }
          System.out.println("1.Read\n2.Display");
          swCase=Integer.parseInt(br.readLine());
          switch(swCase)
          {
            case 1:
              for(int i =0;i<Ccount;i++)
              {
                com[i].read();
              }
              break;
            case 2:
              for(int i =0;i<Ccount;i++)
              {
                com[i].display();
              }
          }
          break;
        case 2:
          System.out.println("Enter Number of Free Ads - ");
          freeCount=Integer.parseInt(br.readLine());
          free=new Free_ad[freeCount];
          for(int i=0;i<freeCount;i++)
          {
            free[i]= new Free_ad();
          }
          System.out.println("1.Read\n2.Display");
          swCase=Integer.parseInt(br.readLine());
          switch(swCase)
          {
            case 1:
              for(int i =0;i<free.length;i++)
              {
                free[i].read();
              }
              break;
            case 2:
              for(int i =0;i<free.length;i++)
              {
                free[i].display();
              }
          }
          break;
        case 3:
          for(int i=0; i<com.length;i++)
          {
            if(com[i].price_of_add>3000)
            {
              com[i].display();
            }
          }
          break;
        case 4:
          for(int i=0; i<free.length;i++)
          {
            free[i].display();
          }
          break;
      }
    }
  }
}


class Advertisement
{
  private String cust_name;
  private String start_date;
  private static int advertisement_id;
  private int advert_id;
  static{
    advertisement_id=0;
  }
  BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
  public void read()throws IOException
  {
    System.out.println("Enter Customer Name-");
    cust_name=br.readLine();
    System.out.println("Enter start_date(MM-DD-YYYY)-");
    start_date=br.readLine();
  }
  public void display()
  {
    System.out.println("Cust_name-"+cust_name);
    System.out.println("Advert_id-"+advert_id);
    System.out.println("start_date-"+start_date);
  }
}


class Commercial_ad extends Advertisement
{
  BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
  public int size_of_add;
  public float price_of_add;
  public void read()throws IOException
  {
    System.out.println("Enter Size - ");
    size_of_add=Integer.parseInt(br.readLine());
    System.out.println("Enter Price - ");
    price_of_add=Float.parseFloat(br.readLine());
  }
  public void display()
  {
    System.out.println("Size - "+size_of_add);
    System.out.println("Price - "+price_of_add);
  }
}

class Free_ad extends Advertisement
{
  public int free_ad_time_duration;
  BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
  public void read()throws IOException
  {
    System.out.println("Enter time duration for ad - ");
    free_ad_time_duration=Integer.parseInt(br.readLine());
  }
  public void display()
  {
    System.out.println("Time Duration - "+free_ad_time_duration);
  }
}
