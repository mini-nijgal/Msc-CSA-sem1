{
	"auto_complete":
	{
		"selected_items":
		[
			[
				"co",
				"contNumb"
			],
			[
				"Expe",
				"Exception"
			],
			[
				"Candi",
				"Candidate"
			],
			[
				"Cand",
				"Candidate"
			]
		]
	},
	"buffers":
	[
		{
			"file": "Customerr.java",
			"settings":
			{
				"buffer_size": 1642,
				"encoding": "UTF-8",
				"line_ending": "Windows"
			}
		},
		{
			"file": "/D/office/Todo/To do",
			"settings":
			{
				"buffer_size": 10718,
				"encoding": "UTF-8",
				"line_ending": "Windows"
			}
		},
		{
			"file": "Tests.java",
			"settings":
			{
				"buffer_size": 2746,
				"encoding": "UTF-8",
				"line_ending": "Windows",
				"name": "import java.io.*;"
			}
		},
		{
			"file": "AdvProgram.java",
			"settings":
			{
				"buffer_size": 4982,
				"line_ending": "Windows"
			}
		},
		{
			"contents": "import java.io.*;\n\nclass advertising\n{\n  public static void main(String args[])throws IOException\n  {\n    int cas, swCase, Ccount, freeCount;\n    Commercial_ad [] com = null;\n    Free_ad [] free = null;\n    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));\n    while(true)\n    {\n      System.out.println(\"1.Commercial_ad\\n2.Free_ad\\n3.Commercial_ad with cost>3000 display\\n4.All free_ads\");\n      cas=Integer.parseInt(br.readLine());\n      switch(cas)\n      {\n        case 1:\n          System.out.println(\"Enter Number of Commercial Ads - \");\n          Ccount=Integer.parseInt(br.readLine());\n          com=new Commercial_ad[Ccount];\n          for(int i=0;i<Ccount;i++)\n          {\n            com[i]= new Commercial_ad();\n          }\n          System.out.println(\"1.Read\\n2.Display\");\n          swCase=Integer.parseInt(br.readLine());\n          switch(swCase)\n          {\n            case 1:\n              for(int i =0;i<Ccount;i++)\n              {\n                com[i].read();\n              }\n              break;\n            case 2:\n              for(int i =0;i<Ccount;i++)\n              {\n                com[i].display();\n              }\n          }\n          break;\n        case 2:\n          System.out.println(\"Enter Number of Free Ads - \");\n          freeCount=Integer.parseInt(br.readLine());\n          free=new Free_ad[freeCount];\n          for(int i=0;i<freeCount;i++)\n          {\n            free[i]= new Free_ad();\n          }\n          System.out.println(\"1.Read\\n2.Display\");\n          swCase=Integer.parseInt(br.readLine());\n          switch(swCase)\n          {\n            case 1:\n              for(int i =0;i<free.length;i++)\n              {\n                free[i].read();\n              }\n              break;\n            case 2:\n              for(int i =0;i<free.length;i++)\n              {\n                free[i].display();\n              }\n          }\n          break;\n        case 3:\n          for(int i=0; i<com.length;i++)\n          {\n            if(com[i].price_of_add>3000)\n            {\n              com[i].display();\n            }\n          }\n          break;\n        case 4:\n          for(int i=0; i<free.length;i++)\n          {\n            free[i].display();\n          }\n          break;\n      }\n    }\n  }\n}\n\n\nclass Advertisement\n{\n  private String cust_name;\n  private String start_date;\n  private static int advertisement_id;\n  private int advert_id;\n  static{\n    advertisement_id=0;\n  }\n  BufferedReader br = new BufferedReader(new InputStreamReader(System.in));\n  public void read()throws IOException\n  {\n    System.out.println(\"Enter Customer Name-\");\n    cust_name=br.readLine();\n    System.out.println(\"Enter start_date(MM-DD-YYYY)-\");\n    start_date=br.readLine();\n  }\n  public void display()\n  {\n    System.out.println(\"Cust_name-\"+cust_name);\n    System.out.println(\"Advert_id-\"+advert_id);\n    System.out.println(\"start_date-\"+start_date);\n  }\n}\n\n\nclass Commercial_ad extends Advertisement\n{\n  BufferedReader br = new BufferedReader(new InputStreamReader(System.in));\n  public int size_of_add;\n  public float price_of_add;\n  public void read()throws IOException\n  {\n    System.out.println(\"Enter Size - \");\n    size_of_add=Integer.parseInt(br.readLine());\n    System.out.println(\"Enter Price - \");\n    price_of_add=Float.parseFloat(br.readLine());\n  }\n  public void display()\n  {\n    System.out.println(\"Size - \"+size_of_add);\n    System.out.println(\"Price - \"+price_of_add);\n  }\n}\n\nclass Free_ad extends Advertisement\n{\n  public int free_ad_time_duration;\n  BufferedReader br= new BufferedReader(new InputStreamReader(System.in));\n  public void read()throws IOException\n  {\n    System.out.println(\"Enter time duration for ad - \");\n    free_ad_time_duration=Integer.parseInt(br.readLine());\n  }\n  public void display()\n  {\n    System.out.println(\"Time Duration - \"+free_ad_time_duration);\n  }\n}\n",
			"settings":
			{
				"buffer_size": 3865,
				"line_ending": "Windows",
				"name": "import java.io.*;"
			}
		},
		{
			"contents": "To work on the Invoice API -Apoorv\nTo work on  \"Capacity finder\" (Transaction) -- Production access-  Anuj\nTeam to explore strip API- samples from Git and try out\nTeam to create Lucid charts\nFollow through service requests on DM (Closed/open/commented) - Dhamini\nTickets from infrastructure team (reach out to Ken) - Dhamini \nDevelopment piece - writing basic tasks (Front end) - Dhamini\nTracking integration -- Rating (hari to give demo by next day PST) - Dhamini\nReport on dependency and status  - Dhamini\nQA testrail or some other possible way to be enabled on the Jira for developers to access it - Dhamini\nAproov - Invoice Add work order charges number and independant changes - linking[pop up or button]\nAkash customer pop up- part \n50% of the Development has not started yet –Can we establish a get well  plan to have the to development completed in next 6 days(identify those..)\n\nOM-7 [out of scope]and OM-36 newly added [change log]\nDM-38880\n\n\n\nInfra team - ken  - kk\nlocation intelligence - No details\n\nPLAT-2658 Location Names (UNLOC code- duns)\nPLAT-2652 Address validation - Google Place API vs Address Doctor\nPLAT-2655 Duplication Locations - Clean up\nPLAT-2656 Manage Locations (My Locations)\nPLAT-2653 Location API v2 version enhancement\nPLAT-2654 New API needs to be added for Location v2 version\nBUN-2056 \n\nBLUM-2055      No grooming\nBLUM-2056      No grooming\nthese are not groomed yet\n\nDM-38872\nCarrierGO Premium: Street Turn recommendation provided to users - TBD Scope\nPriority: P2 - High\n\nBACKLOG\nIssue type: Story\nDM-38873\nCarrierGO Premium: Ability to create Street Turns request from CarrierGO-TBD Scope\n\nUnlinked stories from this epic DM-38864:\nhttps://rezone.atlassian.net/browse/DM-38872 \nhttps://rezone.atlassian.net/browse/DM-38873\n\nDM-39177- Switch Driver Functionality -User should have ability to switch driver on a Job. status changed from backlog to dev in progress\nDM-39178\n\nCarrierGoPremium: Additional Functionality\n\n\n\nAnuj and akash - Fleet\nHari to come back with the demo \ntraing QA and Prod - abhi singh and kk\n\n\nBUN2513\n14 - \n\nDM - \n\n\nhttps://rezone.atlassian.net/browse/DM-38774 - Prabhi to confirm\nhttps://rezone.atlassian.net/browse/DM-39098 - Ashish to con\n\n\n39777 - Removed \nDM-39098-> Not doing in mars \nDM-38920-> Prabhi has to confirm it what needs to be done in that\nDM-38919-> Haven't started on it will change the status today\n\nhttps://rezone.atlassian.net/browse/DM-38919\nhttps://rezone.atlassian.net/browse/DM-38917 added description\n\nConflu\nstatus\n////dev2////\nIntegration dev - L-M-H\n\n\n\n\nvisibility-micro-ui : \nshipment frontend : sivaram\nShipment backend : sivaram\nvisibility-api\nalerts-micro-ui\nalerts-notifications-services : anusha\nshipmentevents-processor\nvisibility-logistics-sharedservices\nvisibilityfreightconnector-api\nvisibility-notify \nBlume Universe/ KPI FE2 : mayank\nBlume Universe/ KPI BE : Mayank\n\ngcp cas: chandrasekar team\n",
			"settings":
			{
				"buffer_size": 2899,
				"line_ending": "Windows",
				"name": "To work on the Invoice API -Apoorv"
			}
		},
		{
			"file": "AssetManager.java",
			"settings":
			{
				"buffer_size": 9427,
				"line_ending": "Windows"
			}
		},
		{
			"contents": "import java.io.*;\nclass Account\n{\n     final public String bankName=\"SBI\";\t\n\tString custName;\n\tprivate int accno;\n\tprivate float balance;\n\tAccount()\n\t{\n\t\tcustName=\"\";\n\t\taccno=-1;\n\t}\n\t\n\t\n\tpublic void read()\n\t{\n\t\tInputStreamReader isr=new InputStreamReader(System.in);\n\t\tBufferedReader br=new BufferedReader(isr);\n\t\ttry\n\t\t{\n\t\tSystem.out.println(\"\\nEnter the Customer Name\");\n\t\tcustName=br.readLine();\n\t\tSystem.out.println(\"\\n Enter the Account Number\");\n\t\taccno=Integer.parseInt(br.readLine());\n\t\tSystem.out.println(\"\\nEnter the Balance\");\n\t\tbalance=Float.parseFloat(br.readLine());\n\t\t  }\n\t   catch(Exception e)\n\t\t   {\n\t\t   System.out.println(e.toString());\n\t\t   }\n\n\t}\n\tpublic void dispAccount()\n\t{\n\t\tSystem.out.println(\"ACustomer Name =\"+custName);\n\t\tSystem.out.println(\"Account Number =\"+accno);\n\t\t//System.out.println(\"Balance Amount =\"+balance);\n\n\t}\n\t\n}\n\n class LoanAccount extends Account\n{\n\tfloat intRate;\n\tint amountSanc;\n\tpublic LoanAccount()\n\t{  \tintRate=(float)0.0;\n\t\tamountSanc=0;\n\t}\n\t\n\tpublic void read()\n\t {     \n    \t    super.read();\n         InputStreamReader isr=new InputStreamReader(System.in);\n\t   BufferedReader br=new BufferedReader(isr);\n    \t   try\n\t\t{\n\t\tSystem.out.println(\"Enter the Interest rate\");\n\t\tintRate=Float.parseFloat(br.readLine());\n\t\tSystem.out.println(\"Enter the maximum amount sanctioned\");\n\t\tamountSanc=Integer.parseInt(br.readLine());\n\t\t\t\n\t\t\t}\n\t\t\tcatch(Exception e)\n\t\t   {\n\t\t   System.out.println(e.toString());\n\t\t   }\n\t\t   \n  \t }\n\n\tpublic void dispLoanAccount()\n\t{\n\t\t\t\t\n\tdispAccount();\n\t//accesss specifiers\n\tSystem.out.println(\"Interest rate : \"+intRate);\n\t//System.out.println(\"Account No : \"+accno);\n\tSystem.out.println(\"Maximum amount sanctioned : \"+amountSanc);\n\t}\n}\nclass  CarLoan extends LoanAccount\n{\n\tString carCompany;\n\tString carModel;\n\tint carCost;\n\t\n\tpublic void read()\n\t {     \n    \t   InputStreamReader isr=new InputStreamReader(System.in);\n\t\t   BufferedReader br=new BufferedReader(isr);\n    \t   try\n\t\t\t{\n\t\t\tsuper.read();\n\t\t\tSystem.out.println(\"Enter the car Company Name\");\n\t\t\tcarCompany=br.readLine();\n\t\t\t\n\t\t\tSystem.out.println(\"Enter the car Model\");\n\t\t\tcarModel=br.readLine();\n\t\t\tSystem.out.println(\"Enter the car cost\");\n\t\t\tcarCost=Integer.parseInt(br.readLine());\n\t\t\t\n\t\t\t\n\t\t\t}\n\t\t\tcatch(Exception e)\n\t\t   {\n\t\t   System.out.println(e.toString());\n\t\t   }\n  \t }\n\t public void dispCarLoan()\n\t\t{\n\t\tdispLoanAccount();\n\t    System.out.println(\"Car Company Name :\"+carCompany);\n\t\tSystem.out.println(\"Car Model :\"+carModel);\n\t\tSystem.out.println(\"Car cost :\"+carCost);\n\t\t\t\n\t}\n\n}\n\npublic class Inheritance\n{\n\t\npublic static void main(String []args)\n{\n\nAccount a2=new Account();\na2.bankName=\"SIB\";\nSystem.out.println(a2.bankName);\n/*a2.read();\na2.dispAccount();\nLoanAccount lc=new LoanAccount();\nlc.read();\nlc.dispLoanAccount();\nCarLoan cl=new CarLoan();\ncl.readCarLoan();\ncl.dispCarLoan();*/\n}\n\n\n}\n\n\n\n\n/*class SavingAccount extends Account\n{\n\tprivate float minbal;\n\t\n\tpublic void read()\n\t {\n    \t   InputStreamReader isr=new InputStreamReader(System.in);\n\t\t   BufferedReader br=new BufferedReader(isr);\n    \t   try\n\t\t\t{\n\t\t\tsuper.read();\n\t\t\tSystem.out.println(\"Enter the minimum balance\");\n\t\t\tminbal=Float.parseFloat(br.readLine());\n\t\t\t}\n\t\t\tcatch(Exception e)\n\t\t   {\n\t\t   System.out.println(e.toString());\n\t\t   }\n  \t }\n\t\t   float interestCalc()\n\t\t   {\n\t\t\tfloat inte=(float)0.04*minbal;\t\t\t \n\t\t\t return inte;\n\t\t   }\n\n\tpublic void disp()\n\t{\n\tsuper.disp();\n\t//accesss specifiers\n\tSystem.out.println(\"Minimum balance : \"+minbal);\n\t//System.out.println(\"Account No : \"+accno);\n\n\t}\n\n}*/",
			"settings":
			{
				"buffer_size": 3529,
				"line_ending": "Windows",
				"name": "import java.io.*;"
			}
		},
		{
			"file": "MY CODE SHIPMENTLIST",
			"settings":
			{
				"buffer_size": 749,
				"encoding": "UTF-8",
				"line_ending": "Windows",
				"name": "//mycode"
			}
		},
		{
			"contents": "Damini \n\nPoor english \nNot fancy\nNot diciplined \nfat\nugly\nCant maintanine \n",
			"settings":
			{
				"buffer_size": 75,
				"line_ending": "Windows",
				"name": "Damini"
			}
		}
	],
	"build_system": "",
	"build_system_choices":
	[
	],
	"build_varint": "",
	"command_palette":
	{
		"height": 0.0,
		"last_filter": "",
		"selected_items":
		[
		],
		"width": 0.0
	},
	"console":
	{
		"height": 0.0,
		"history":
		[
		]
	},
	"distraction_free":
	{
		"menu_visible": true,
		"show_minimap": false,
		"show_open_files": false,
		"show_tabs": false,
		"side_bar_visible": false,
		"status_bar_visible": false
	},
	"file_history":
	[
		"/D/office/To do",
		"/D/office/QA"
	],
	"find":
	{
		"height": 0.0
	},
	"find_in_files":
	{
		"height": 0.0,
		"where_history":
		[
		]
	},
	"find_state":
	{
		"case_sensitive": false,
		"find_history":
		[
		],
		"highlight": true,
		"in_selection": false,
		"preserve_case": false,
		"regex": false,
		"replace_history":
		[
		],
		"reverse": false,
		"show_context": true,
		"use_buffer2": true,
		"whole_word": false,
		"wrap": true
	},
	"groups":
	[
		{
			"selected": 6,
			"sheets":
			[
				{
					"buffer": 0,
					"file": "Customerr.java",
					"semi_transient": false,
					"settings":
					{
						"buffer_size": 1642,
						"regions":
						{
						},
						"selection":
						[
							[
								1433,
								1433
							]
						],
						"settings":
						{
							"syntax": "Packages/Java/Java.sublime-syntax",
							"tab_size": 2,
							"translate_tabs_to_spaces": true
						},
						"translation.x": 0.0,
						"translation.y": 0.0,
						"zoom_level": 1.0
					},
					"stack_index": 8,
					"type": "text"
				},
				{
					"buffer": 1,
					"file": "/D/office/Todo/To do",
					"semi_transient": false,
					"settings":
					{
						"buffer_size": 10718,
						"regions":
						{
						},
						"selection":
						[
							[
								10718,
								10718
							]
						],
						"settings":
						{
							"syntax": "Packages/Text/Plain text.tmLanguage"
						},
						"translation.x": 0.0,
						"translation.y": 4011.0,
						"zoom_level": 1.0
					},
					"stack_index": 9,
					"type": "text"
				},
				{
					"buffer": 2,
					"file": "Tests.java",
					"semi_transient": false,
					"settings":
					{
						"buffer_size": 2746,
						"regions":
						{
						},
						"selection":
						[
							[
								2385,
								2385
							]
						],
						"settings":
						{
							"auto_name": "import java.io.*;",
							"syntax": "Packages/Java/Java.sublime-syntax",
							"tab_size": 2,
							"translate_tabs_to_spaces": true
						},
						"translation.x": 0.0,
						"translation.y": 845.0,
						"zoom_level": 1.0
					},
					"stack_index": 7,
					"type": "text"
				},
				{
					"buffer": 3,
					"file": "AdvProgram.java",
					"semi_transient": false,
					"settings":
					{
						"buffer_size": 4982,
						"regions":
						{
						},
						"selection":
						[
							[
								3674,
								3674
							]
						],
						"settings":
						{
							"syntax": "Packages/Java/Java.sublime-syntax",
							"translate_tabs_to_spaces": false
						},
						"translation.x": 0.0,
						"translation.y": 2285.0,
						"zoom_level": 1.0
					},
					"stack_index": 6,
					"type": "text"
				},
				{
					"buffer": 4,
					"semi_transient": false,
					"settings":
					{
						"buffer_size": 3865,
						"regions":
						{
						},
						"selection":
						[
							[
								3865,
								3865
							]
						],
						"settings":
						{
							"auto_name": "import java.io.*;",
							"syntax": "Packages/Text/Plain text.tmLanguage",
							"tab_size": 2,
							"translate_tabs_to_spaces": true
						},
						"translation.x": 0.0,
						"translation.y": 2217.0,
						"zoom_level": 1.0
					},
					"stack_index": 5,
					"type": "text"
				},
				{
					"buffer": 5,
					"semi_transient": false,
					"settings":
					{
						"buffer_size": 2899,
						"regions":
						{
						},
						"selection":
						[
							[
								2898,
								2898
							]
						],
						"settings":
						{
							"auto_name": "To work on the Invoice API -Apoorv",
							"syntax": "Packages/Text/Plain text.tmLanguage"
						},
						"translation.x": 0.0,
						"translation.y": 709.0,
						"zoom_level": 1.0
					},
					"stack_index": 1,
					"type": "text"
				},
				{
					"buffer": 6,
					"file": "AssetManager.java",
					"semi_transient": false,
					"settings":
					{
						"buffer_size": 9427,
						"regions":
						{
						},
						"selection":
						[
							[
								0,
								0
							]
						],
						"settings":
						{
							"syntax": "Packages/Java/Java.sublime-syntax",
							"translate_tabs_to_spaces": false
						},
						"translation.x": 0.0,
						"translation.y": 0.0,
						"zoom_level": 1.0
					},
					"stack_index": 0,
					"type": "text"
				},
				{
					"buffer": 7,
					"semi_transient": false,
					"settings":
					{
						"buffer_size": 3529,
						"regions":
						{
						},
						"selection":
						[
							[
								39,
								39
							]
						],
						"settings":
						{
							"auto_name": "import java.io.*;",
							"syntax": "Packages/Text/Plain text.tmLanguage",
							"translate_tabs_to_spaces": false
						},
						"translation.x": 0.0,
						"translation.y": 0.0,
						"zoom_level": 1.0
					},
					"stack_index": 4,
					"type": "text"
				},
				{
					"buffer": 8,
					"file": "MY CODE SHIPMENTLIST",
					"semi_transient": false,
					"settings":
					{
						"buffer_size": 749,
						"regions":
						{
						},
						"selection":
						[
							[
								749,
								749
							]
						],
						"settings":
						{
							"auto_name": "//mycode",
							"syntax": "Packages/Text/Plain text.tmLanguage",
							"translate_tabs_to_spaces": false
						},
						"translation.x": 0.0,
						"translation.y": 0.0,
						"zoom_level": 1.0
					},
					"stack_index": 3,
					"type": "text"
				},
				{
					"buffer": 9,
					"semi_transient": false,
					"settings":
					{
						"buffer_size": 75,
						"regions":
						{
						},
						"selection":
						[
							[
								75,
								75
							]
						],
						"settings":
						{
							"auto_name": "Damini",
							"syntax": "Packages/Text/Plain text.tmLanguage"
						},
						"translation.x": 0.0,
						"translation.y": 0.0,
						"zoom_level": 1.0
					},
					"stack_index": 2,
					"type": "text"
				}
			]
		}
	],
	"incremental_find":
	{
		"height": 0.0
	},
	"input":
	{
		"height": 0.0
	},
	"layout":
	{
		"cells":
		[
			[
				0,
				0,
				1,
				1
			]
		],
		"cols":
		[
			0.0,
			1.0
		],
		"rows":
		[
			0.0,
			1.0
		]
	},
	"menu_visible": true,
	"output.exec":
	{
		"height": 127.0
	},
	"output.find_results":
	{
		"height": 0.0
	},
	"pinned_build_system": "Packages/Java/JavaC.sublime-build",
	"project": "",
	"replace":
	{
		"height": 0.0
	},
	"save_all_on_build": true,
	"select_file":
	{
		"height": 0.0,
		"last_filter": "",
		"selected_items":
		[
		],
		"width": 0.0
	},
	"select_project":
	{
		"height": 500.0,
		"last_filter": "",
		"selected_items":
		[
		],
		"width": 380.0
	},
	"select_symbol":
	{
		"height": 0.0,
		"last_filter": "",
		"selected_items":
		[
		],
		"width": 0.0
	},
	"selected_group": 0,
	"settings":
	{
	},
	"show_minimap": true,
	"show_open_files": true,
	"show_tabs": true,
	"side_bar_visible": true,
	"side_bar_width": 150.0,
	"status_bar_visible": true,
	"template_settings":
	{
	}
}
