import java.io.*;
import java.util.*;
import java.io.Serializable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

class Customer implements Serializable
{
    public int C_id;
    public String C_name;
    public String C_address;
    public String C_no;
    public String D_type;

    //Customer(int C_id, String C_name, String C_address, String C_no, String D_type)
	Customer()
	{
        this.C_id=C_id;
        this.C_name=C_name;
        this.C_address=C_address;
        this.C_no=C_no;
        this.D_type=D_type;
    }

    public void read()
    {
        try 
        {
         InputStreamReader isr= new InputStreamReader(System.in);
         BufferedReader br= new BufferedReader(isr);
         System.out.println("Enter Customer ID:");
         C_id=Integer.parseInt(br.readLine());
         System.out.println("Enter Customer Name:");
         C_name=br.readLine();
         System.out.println("Enter Customer Address:");
         C_address=br.readLine();
         System.out.println("Enter Customer Contact Number:");
         C_no=br.readLine();
         System.out.println("Enter Delivery Type opted:");
         D_type=br.readLine();         
        } 
        catch (Exception e) 
        {
            System.out.println(e.getMessage());
        }
    }
    

    public String display()
    {
        return "Customer ID: " +C_id+ "\n Customer Name: " +C_name+ "\nCustomer Address: " +C_address+ "\n Customer Number: " +C_no+ "\n Delivery Type: " +D_type;
    }
	
	public void search()
	{
		File file = new File("testlab9.txt");
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the Customer Id to search: ");
		String name = sc.next();
		Scanner scanner;
		try
		{
			scanner = new Scanner(file).useDelimiter(",");
			
			while(scanner.hasNext())
			{
				final String datafile = scanner.nextLine();
				if(datafile.contains(name))
				{
					System.out.println("Found Customer ID: "+name);
					break;
				}
			}
		}
		catch(IOException e)
		{
			System.out.println("Cannot write to file "+file.toString());
		}
	}
}

public class Lab9 
{
 public static void main(String args[]) throws IOException
 {
     //Customer C1 = new Customer(1, "Rahul", "Bangalore", "900890", "Express");
     //Customer C2 = new Customer(3, "Raj", "Mysore", "910890", "Standard");
     Customer C1= new Customer();
	 Customer C2= new Customer();
	 C1.read();
	 C2.read();
     try 
     {
      FileOutputStream f = new FileOutputStream(new File("testlab9.txt"));
      ObjectOutputStream o = new ObjectOutputStream(f);

      //write objects to file
      o.writeObject(C1);
      o.writeObject(C2);
      
      o.close();
      f.close();
      
      FileInputStream fi = new FileInputStream(new File("testlab9.txt"));
      ObjectInputStream oi = new ObjectInputStream(fi);

      Customer CS1 = (Customer) oi.readObject();
      Customer CS2 = (Customer) oi.readObject();

      System.out.println(CS1.display());
      System.out.println(CS2.display());

      oi.close();
      fi.close();

     } 
     catch(FileNotFoundException e)
     {
        System.out.println("File not Found");
     }
     catch (IOException e) 
     {
        System.out.println("Error Initializing Stream");
     }
     catch(ClassNotFoundException e)
     {
         e.printStackTrace();
     }
	 C1.search();
	 C2.search();
 }   
}
