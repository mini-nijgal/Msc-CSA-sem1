import java.io.*;
import java.util.Scanner;

class Customer
{
	private String custName;
	private byte custAge;
	private long accNo;
	private char gender;
	private short minBal;
	private float bal;
	private long custId;
	boolean pan;


public void read() throws IOException
{
	
	InputStreamReader isr=new InputStreamReader (System.in);
	BufferedReader br=new BufferedReader (isr); 
	Scanner scan=new Scanner (System.in); 
	System.out.println ("Enter the customer name"); 
	custName=br.readLine(); 
	System.out.println ("Enter the customer age"); 
	custAge=Byte.parseByte (br.readLine()); 
	System.out.println ("Enter the customer account number");
	accNo=Long.parselong (br.readLine ());
	System.out.println("Enter the Minimum Balance"); 
	minBal=Short.parseShort (br.readLine()); 
	System.out.println ("Enter the Balance Amount ");
	// bal-Float.valueOf (br.readLine ()).floatValue ()
	bal=Float.parseFloat(br.readLine());
	//bal=scan.nextFloat ();
	System.out.println ("Enter the customer Gender"); gender= (char)br.read () ;
	System.out.println("Do you have Pan Card");
	pan=Boolean.parse; Boolean (br.readLine());
}

public void disp()
{
	System.out.println("Customer Name ="+custName) ; 
	System.out.println("Customer Age="+custAge);
	System.out.println("Customer Account Number ="+ accNo);
	System.out.println("Pan Card="+pan);
	//pan-Boolean.Parse; Boolean(br.readLine());
	pan = Boolean.parse;
	
	System.out.println("Customer Gender="+gender);
	System.out.println("Customer Balance="+bal);

	System.out.println("\n");
	 Boolean(br.readLine());
	// boolean bn = n. next Boolean();


}

public static void main(String[] args)
{
try
{
Customer obj=new Customer();
obj.read(); 
obj.disp();
}
catch (IOException e)
{
}
}
}

class Test
{
public static void main(String[] args)
{
try
{
Customer obj=new Customer();
obj.read(); 
obj.disp();
}
catch (IOException e)
{
}
}
}

