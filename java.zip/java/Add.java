
import java.util.Scanner;


class CommercialAdd{

private  float size_of_add;
private float price_per_cm;
private float price;


public void read(){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size_of_add");
		size_of_add = sc.nextFloat();
		System.out.println("Enter price_per_cm");
		price_per_cm = sc.nextFloat();

	}


public void display(){
 
	      System.out.println("size_of_add ="+size_of_add);
          System.out.println("price_per_cm"+price_per_cm);
}

public float getPrice(){

	price = size_of_add*price_per_cm;
	return price;

}


}


class FreeAdd extends CommercialAdd

{
	private int free_add_time_duration;


public void read(){
	super.read();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter duration");
		free_add_time_duration = sc.nextInt();
		

	}


public void display(){
 
 super.display();
	      
          System.out.println("free_add_time_duration"+free_add_time_duration);
}


public float getNoOfAdd(){
	return free_add_time_duration;
}


}







class Advertisement  extends FreeAdd{
	
	private int advertisement_id;
	private String client_name;
	private String start_date;
	public static int add_id=100;


	Advertisement(){
		advertisement_id=++add_id;
	}



	public void read(){
		super.read();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Person Name");
		client_name = sc.nextLine();
		System.out.println("Enter start_date");
		start_date = sc.nextLine();

	}
	public void display(){
            super.display();
          System.out.println(" Advertisement id ="+advertisement_id);
          System.out.println("Client Name ="+client_name);
          System.out.println("start_date"+start_date);


	}


}










class Add{


	public static void main(String[] args) {

		int ch=0;
		int c=0;

	Advertisement obj[] = new Advertisement[5];

		do{
		Scanner sc = new Scanner(System.in);
		System.out.println("1:Read Data");
		System.out.println("2:Display Data");
		System.out.println("3:more than 5000 price");
		System.out.println("4:more than 2 add");

		System.out.println("Enter Choice");
		ch=sc.nextInt();

   
		switch(ch)
		{
			case 1:
			obj[c] = new Advertisement();
			obj[c].read();
			c++; 

			break;

			case 2:
			for(int i=0;i<c;i++){
				obj[i].display();
			}
            

			break;

			case 3:
			for (int i=0;i<c;i++){
					if(obj[i].getPrice() >5000) {
						obj[i].display();
					}
				}

			break;

			case 4:

			for (int i=0;i<c;i++){
					if(obj[i].getNoOfAdd() >2) {
						obj[i].display();
					}
				}

			break;

			default:

			System.out.println("Wrong choice");


		}

	}while(ch!=0);
	}
	


}