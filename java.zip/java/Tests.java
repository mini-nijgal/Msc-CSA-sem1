import java.io.*;
import java.util.Scanner;

class Candidate
{
  private String candName;
  private byte candId;
  private Long dob;
  private byte candAge;
	private String candEdu;
  private String candCer;
  private String perfLoca;
	private long salary;
  private long contNumb;
  private String candMail;
	private char gender;
	boolean passport;
  public void read() throws IOException
  {
    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
    Scanner scan=new Scanner(System.in);
    System.out.println("Enter the Candidate Name"); // Name 
    candName=br.readLine();
    System.out.println("Enter the Candidate Id");   // Id number only
    candId=Byte.parseByte(br.readLine());
    System.out.println("Enter the DOB"); //dob[26091999]
    dob=Long.parseLong(br.readLine());
    System.out.println("Enter the Candidate age");  //Age
    candAge=Byte.parseByte(br.readLine());
    System.out.println("Enter the Candidate Highest Education");  // UG or PG
    candEdu=br.readLine();
    System.out.println("Enter the Certification");  // certification
    candCer=br.readLine();
    System.out.println("Enter the prefered location");  // Perffered location
    perfLoca=br.readLine();
    System.out.println("Enter the Expeted salary "); // salary
    salary=Long.parseLong(br.readLine());
    System.out.println("Enter the Contact Number "); // number
    contNumb=Long.parseLong(br.readLine());
    System.out.println("Enter the Candidate Email");  // Email
    candMail=br.readLine();
    System.out.println("Enter the Candidate Gender"); // Gender
    gender=(char)br.read();
    br.readLine();
    System.out.println("Do you have a Passport"); // passport
    passport=Boolean.parseBoolean(br.readLine());
  }
  public void disp()
  {
    System.out.println("Candidate Name = "+candName);
    System.out.println("Candidate Id = "+candId);
    System.out.println("Candidate's DOB = "+dob);
    System.out.println("Candidate's Age = "+candAge);
    System.out.println("Candidate's Highest Education = "+candEdu);
    System.out.println("Candidate's Additional Certification = "+candCer);
    System.out.println("Candidate's Prefered Location = "+perfLoca);
    System.out.println("Candidate's salary expectation = "+salary);
    System.out.println("Candidate's Contact Number = "+contNumb);
    System.out.println("Candidate's E-mail Id = "+candMail);
    System.out.println("Candidate Gender = "+gender);
    System.out.println("\n");
    System.out.println("Candidate Passport = "+passport);
  }

}
class Tests
{
  public static void main(String [] args)
  {
    try{
      Candidate obj=new Candidate();
      obj.read();
      obj.disp();
    }
    catch(IOException e)
    {
      
    }
  }//closing main
}