import java.io.*;
import java.util.Scanner;

class Candidate
{
  private String custName;
	private byte custAge;
	private long accNo;
	private char gender;
	private short minBal;
	private float bal;
	private long custId;
	boolean pan;
  public void read() throws IOException
  {
    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
    Scanner scan=new Scanner(System.in);
    System.out.println("Enter the customer name");
    custName=br.readLine();
    System.out.println("Enter the customer age");
    custAge=Byte.parseByte(br.readLine());
    System.out.println("Enter the customer account Number");
    accNo=Long.parseLong(br.readLine());
    System.out.println("Enter the Minimum Balance");
    minBal=Short.parseShort(br.readLine());
    System.out.println("Enter the BalanceAmount");
    bal=Float.parseFloat(br.readLine());
    System.out.println("Enter the Customer Gender");
    gender=(char)br.read();
    br.readLine();
    System.out.println("Do you have a PAN Card");
    pan=Boolean.parseBoolean(br.readLine());
  }
  public void disp()
  {
    System.out.println("Customer name = "+custName);
    System.out.println("Customer Age = "+custAge);
    System.out.println("Customer Account Number = "+accNo);
    System.out.println("Customer Gender = "+gender);
    System.out.println("Customer Balance = "+bal);
    System.out.println("\n");
    System.out.println("Pan Card = "+pan);
  }

}
class Test
{
  public static void main(String [] args)
  {
    try{
      Candidate obj=new Candidate();
      obj.read();
      obj.disp();
    }
    catch(IOException e)
    {
      
    }
  }//closing main
}