import java.io.*;
class Account
{
     //final public String bankName="SBI";	
	String custName;//data mem
	private int accno;//data mem
	private float balance;//data mem
	Account()
	{
		custName="";
		accno=-1;
	}
	
	
	public void readAccount()
	{
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		try
		{
		System.out.println("\nEnter the Customer Name");
		custName=br.readLine();
		System.out.println("\n Enter the Account Number");
		accno=Integer.parseInt(br.readLine());
		System.out.println("\nEnter the Balance");
		balance=Float.parseFloat(br.readLine());
		  }
	   catch(Exception e)
		   {
		   System.out.println(e.toString());
		   }

	}
	public void dispAccount()
	{
		System.out.println("ACustomer Name ="+custName);
		System.out.println("Account Number ="+accno);
		//System.out.println("Balance Amount ="+balance);

	}
	
}

 class LoanAccount extends Account
{
	float intRate;//data member
	int amountSanc;//data members
	public LoanAccount()
	{  	intRate=(float)0.0;
		amountSanc=0;
	}
	
	public void readLoanAccount()
	 {     
    	    //super.read();
	   readAccount();
           InputStreamReader isr=new InputStreamReader(System.in);
	   BufferedReader br=new BufferedReader(isr);
    	   try
		{
		System.out.println("Enter the Interest rate");
		intRate=Float.parseFloat(br.readLine());
		System.out.println("Enter the maximum amount sanctioned");
		amountSanc=Integer.parseInt(br.readLine());
			
			}
			catch(Exception e)
		   {
		   System.out.println(e.toString());
		   }
		   
  	 }

	public void dispLoanAccount()
	{
				
	dispAccount();
	//accesss specifiers
	System.out.println("Interest rate : "+intRate);
	//System.out.println("Account No : "+accno);
	System.out.println("Maximum amount sanctioned : "+amountSanc);
	}
}
/*class  CarLoan extends LoanAccount
{
	String carCompany;//data mem
	String carModel;//data mem
	int carCost;
	
	public void read()
	 {     
    	   InputStreamReader isr=new InputStreamReader(System.in);
		   BufferedReader br=new BufferedReader(isr);
    	   try
			{
			super.read();
			System.out.println("Enter the car Company Name");
			carCompany=br.readLine();
			
			System.out.println("Enter the car Model");
			carModel=br.readLine();
			System.out.println("Enter the car cost");
			carCost=Integer.parseInt(br.readLine());
			
			
			}
			catch(Exception e)
		   {
		   System.out.println(e.toString());
		   }
  	 }
	 public void dispCarLoan()
		{
		dispLoanAccount();
	        System.out.println("Car Company Name :"+carCompany);
		System.out.println("Car Model :"+carModel);
		System.out.println("Car cost :"+carCost);
			
	}

}*/

public class Inheritance
{
	
public static void main(String []args)
{

LoanAccount obj = new LoanAccount();
obj.readLoanAccount();
obj.dispLoanAccount();

/*
Account a2=new Account();
//a2.bankName="SIB";
//System.out.println(a2.bankName);
a2.read();
a2.dispAccount();
LoanAccount lc=new LoanAccount();
lc.read();
lc.dispLoanAccount();
CarLoan cl=new CarLoan();
cl.readCarLoan();
cl.dispCarLoan();*/
}


}




/*class SavingAccount extends Account
{
	private float minbal;
	
	public void read()
	 {
    	   InputStreamReader isr=new InputStreamReader(System.in);
		   BufferedReader br=new BufferedReader(isr);
    	   try
			{
			super.read();
			System.out.println("Enter the minimum balance");
			minbal=Float.parseFloat(br.readLine());
			}
			catch(Exception e)
		   {
		   System.out.println(e.toString());
		   }
  	 }
		   float interestCalc()
		   {
			float inte=(float)0.04*minbal;			 
			 return inte;
		   }

	public void disp()
	{
	super.disp();
	//accesss specifiers
	System.out.println("Minimum balance : "+minbal);
	//System.out.println("Account No : "+accno);

	}

}*/