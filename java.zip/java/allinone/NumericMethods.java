package support;

public interface NumericMethods {
	public int getInteger();
	public long getLong();
	public float getFloat();
	public int getIntegerWithCannotBeZeroValidation();
}
