import support.UserInputs;

public class Software extends Assets {
	private float softwareVersion;
	private String softwareCatagory;

	public Software(String assetType) {
		super(assetType);
		UserInputs inputParam = new UserInputs();
		System.out.println("Enter software version");
		this.setSoftwareVersion(inputParam.getLong());
		System.out.println("Enter software catagory");
		this.setSoftwareCatagory(inputParam.getString());
	}
	
	public void Display() {
		super.Display();
		System.out.println("Software Version " + this.getSoftwareVersion());
		System.out.println("Software Catagory " + this.getSoftwareCatagory());
	}
	
	public void Edit() {
		super.Edit();
		UserInputs inputParam = new UserInputs();
		System.out.println("Enter software version | Current Version " + this.getSoftwareVersion());
		this.setSoftwareVersion(inputParam.getFloat());
		System.out.println("Enter software catagory | Current Catagory " + this.getSoftwareCatagory());
		this.setSoftwareCatagory(inputParam.getString());
	}

	public float getSoftwareVersion() {
		return softwareVersion;
	}
	public void setSoftwareVersion(float softwareVersion) {
		this.softwareVersion = softwareVersion;
	}
	public String getSoftwareCatagory() {
		return softwareCatagory;
	}
	public void setSoftwareCatagory(String softwareCatagory) {
		this.softwareCatagory = softwareCatagory;
	}
}
