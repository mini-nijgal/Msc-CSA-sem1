package support;

abstract public class CoreAssetFunctions{
	//abstract class
	abstract public void CreateCompanyAsset(String assetType);
	abstract public void Display();
	abstract public void Edit();
	 
}
