package support;

public interface StringMethods {
	public String getString();
}
