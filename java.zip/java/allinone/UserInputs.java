package support;

import java.util.Scanner;
@SuppressWarnings("resource")
public class UserInputs implements NumericMethods, StringMethods {
	public int getInteger() {
		// return int value
		String param = null;
		try {
			Scanner scanValidate = new Scanner(System.in);
			param = scanValidate.nextLine();
			if(!param.matches("\\d+")){
				throw new CustomExceptions("Invalid Input - Enter numeric value only");
				}
			return Integer.parseInt(param);
		} catch (CustomExceptions ex) {
			return getInteger();
		} 
	}
	
	public long getLong() {
		//returns long value
		String param = null;
		try {
			Scanner scanValidate = new Scanner(System.in);
			param = scanValidate.nextLine();
			if(!param.matches("\\d+")){
				throw new CustomExceptions("Invalid Input - Enter numeric value only");
			}
			return Long.parseLong(param);
		} catch (CustomExceptions ex) {
			return getLong();
		} 
		
	}

	public float getFloat() {
		//returns float value
		String param = null;
		try {
			Scanner scanValidate = new Scanner(System.in);
			param = scanValidate.nextLine();
			if(!param.matches("[+-]?[0-9]+(\\.[0-9]+)?([Ee][+-]?[0-9]+)?")){
				throw new CustomExceptions("Invalid Inupt - Enter decimal value only");
			}
			return Float.parseFloat(param);
		}	catch(CustomExceptions ex) {
			return getFloat();
		}
		
	}
	
	
	public String getString(){
		//Returns String value and only Number Alphabets and space is allowed
		String param = null;
		try {
			Scanner scanValidate = new Scanner(System.in);
			param = scanValidate.nextLine();
			if(!param.matches("[A-Za-z0-9\\s]+")){
				throw new CustomExceptions("Invalid Input - Enter aphabets and space only");
			}
			return param;
		}
		catch(CustomExceptions ex) {
			return getString();
		}
	}
	
	public boolean getCheckYesNo() {
		//returns boolean value based on y and n parameters
		try {
			Scanner scanValidate = new Scanner(System.in);
			String param = scanValidate.nextLine();
			boolean isAcceptable = false;
			if(param.toLowerCase().charAt(0)=='y'){
				isAcceptable = true;
			} else if(param.toLowerCase().charAt(0)=='n'){
				isAcceptable = false;
			} else {
				throw new CustomExceptions("Invalid String, Enter Y or N only");
			}
			return isAcceptable;
		} catch (CustomExceptions ex) {
			return getCheckYesNo();
		}
	}
	
	
	

	public int getIntegerWithCannotBeZeroValidation() {
		// return int value where value cannot be 0
		String param = null;
		try {
			Scanner scanValidate = new Scanner(System.in);
			param = scanValidate.nextLine();
			if(!param.matches("[+-]?\\d+")){
				throw new CustomExceptions("Invalid Input - Enter numeric value only");
			}
			if(Integer.parseInt(param) < 1) {
				throw new IllegalArgumentException("Input cannot be less than or equal to 0");
			}
			return Integer.parseInt(param);
		}	catch (CustomExceptions ex) {
			return getIntegerWithCannotBeZeroValidation();
		}	catch (IllegalArgumentException ex) {
			System.out.println(ex.getMessage());
			return getIntegerWithCannotBeZeroValidation();
		}
	}
}