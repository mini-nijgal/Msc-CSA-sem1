//Demo of Exceptions
//Programmed on 01-10-2020

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import support.UserInputs;


public class AssetManager {
	static class ApplicationConfig { //static class
		protected static String appName = "Test Software"; //static variable
		protected static Float appVersion = 1.0f; 
		public static void setAppName(String newAppName) { //static method
			//static block
			appName = newAppName;
		}
		public static void appInfo(){//static method
			//static block
			System.out.println("***** Applicaiton Configuration *****");
			System.out.println("Applicaiton Name - " + appName);
			System.out.println("Application Version - " + appVersion.toString());
			System.out.println("\n");
		}
	}
	
	public static void main(String[] args) throws FileNotFoundException, IllegalArgumentException, IOException, NullPointerException {

		try {
			FileReader file = new FileReader("C:\\test\\a.txt");
			file.close();
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found Exception Caught: " + e.getMessage());
			System.out.println("\n");
		} catch (IOException ex) {
			System.out.println("IOException Caught: " + ex.getMessage());
			System.out.println("\n");
		} 
		
		try {
			int option = 0;
			Long assetNumber;
			UserInputs inputParam = new UserInputs();
			// ConcurrentHashMap is thread-safe variant of ArrayList
			Map<Long, Laptop> laptopAssets = new ConcurrentHashMap<Long, Laptop>();//to store asset details
			Map<Long, DesktopPC> computerAsssets = new ConcurrentHashMap<Long, DesktopPC>();//to store asset details
			Map<Long, Software> softwareAsssets = new ConcurrentHashMap<Long, Software>();//to store asset details
			Map<Long, String> objectType = new ConcurrentHashMap<Long, String>(); //to store object type based and cast it
			do {
				System.out.println("************ " + ApplicationConfig.appName + " ************ ");
				System.out.println("1. Asset Management");
				System.out.println("2. Application Config");
				System.out.println("0. Exit");
				System.out.println("Enter the below operations");
				option = inputParam.getInteger();
				switch(option){ 
					case 1:
						System.out.println(" ***** Asset*****");
						System.out.println("1. Create New Asset");
						System.out.println("2. View Asset");
						System.out.println("3. Remove Asset");
						System.out.println("4. Edit Asset");
						System.out.println("5. View All Assets");
						switch(inputParam.getInteger()) {
							case 1: 
								System.out.println("### Create new asset ###");
								System.out.println("Enter Asset Catagory");
								System.out.println("1. Laptop");
								System.out.println("2. Desktop PC");
								System.out.println("3. Software");
								switch(inputParam.getInteger()) {
									case 1:
										System.out.println("Enter Laptop Details");
										Laptop laptopObj = new Laptop("Laptop");
										laptopAssets.put(Laptop.staticAssetSlNo, laptopObj);
										objectType.put(Laptop.staticAssetSlNo, "Laptop");
										System.out.println("New Laptop registed with Asset ID : " + Laptop.staticAssetSlNo);
										break;
									case 2:
										System.out.println("Enter Desktop Details");
										DesktopPC desktopObj = new DesktopPC("Desktop PC");
										computerAsssets.put(DesktopPC.staticAssetSlNo, desktopObj);
										objectType.put(DesktopPC.staticAssetSlNo, "DesktopPC");
										System.out.println("New Desktop registed with Asset ID : " + DesktopPC.staticAssetSlNo);
										break;
									case 3:
										System.out.println("Enter Software Details");
										Software software= new Software("Software");
										softwareAsssets.put(Software.staticAssetSlNo, software);
										objectType.put(Software.staticAssetSlNo, "Software");
										System.out.println("New Software registed with Asset ID : " + Software.staticAssetSlNo);
										break;
									}
								
								System.out.println("\n");
								break;
							case 2: 
								System.out.println("### View Asset ###");
								System.out.println("Enter asset number");
								assetNumber =  inputParam.getLong();
								if(objectType.containsKey(assetNumber)){
									switch (objectType.get(assetNumber)){
									case "Laptop":
										System.out.println("Printing laptop");
										laptopAssets.get(assetNumber).Display();
										break;
									case "DesktopPC":
										System.out.println("Printing Desktop");
										computerAsssets.get(assetNumber).Display();
										break;
									
									case "Software":
										System.out.println("Printing Software");
										softwareAsssets.get(assetNumber).Display();
										break;
									}
								}
								else {
									//throwing IllegalArgumentException
									throw new IllegalArgumentException("Invalid Asset ID");
									//System.out.println("Invalid Asset ID");
								}
								System.out.println("\n");
								break;
							case 3: 
								System.out.println("### Remove Asset ###");
								System.out.println("Enter asset number");
								assetNumber = inputParam.getLong();
								if(objectType.containsKey(assetNumber)){
									switch (objectType.get(assetNumber)){
									case "Laptop":
										laptopAssets.remove(assetNumber);
										break;
									case "DesktopPC":
										computerAsssets.remove(assetNumber);
										break;
									case "Software":
										softwareAsssets.remove(assetNumber);
										break;
									}
									objectType.remove(assetNumber);	
									System.out.println("Asset ID " + assetNumber.toString() + " was removed");
								}
								else {
									System.out.println("Invalid Asset ID");
								}
								System.out.println("\n");
								break;
							case 4: 
								System.out.println("### Edit Asset ###");
								System.out.println("Enter asset number");
								assetNumber = inputParam.getLong();
								if(objectType.containsKey(assetNumber)){
									switch (objectType.get(assetNumber)){
									case "Laptop":
										laptopAssets.get(assetNumber).Edit();
										break;
									case "DesktopPC":
										computerAsssets.get(assetNumber).Edit();
										break;
									case "Software":
										softwareAsssets.get(assetNumber).Edit();
										break;
									}
								}
								else {
									//throwing IllegalArgumentException
									throw new IllegalArgumentException("Invalid Asset ID");
									//System.out.println("Invalid Asset ID");
								}
								System.out.println("\n");
								break;

							case 5: 
								System.out.println("### View All Assets ###");
								if(laptopAssets.size() == 0 && computerAsssets.size()==0 && softwareAsssets.size() == 0){
									//System.out.println("No Assets exists");
									//throwing NullPointerException
									throw new NullPointerException("No Assets exists");
								} else {
									if(laptopAssets.size()>0) {
										System.out.println("Printing Laptops");
										laptopAssets.forEach((k,v) -> v.Display());
									}
									if(computerAsssets.size()>0){
										System.out.println("Printing Computers");
										computerAsssets.forEach((k,v) -> v.Display());
									}
									if(softwareAsssets.size()>0){
										System.out.println("Printing Softwares");
										softwareAsssets.forEach((k,v) -> v.Display());
									}
								}
								System.out.println("\n");
								break;
							}
						break;
					case 2: 
						System.out.println(" ***** Application Configuration *****");
						System.out.println("1. View Application Configruation");
						System.out.println("2. Reset Application Configuration");
						System.out.println("0. Return to Main Menu");
						switch(inputParam.getInteger()) {
							case 1:
								ApplicationConfig.appInfo();
								break;
							case 2: 
								System.out.println("***** Reset Application Name *****");
								System.out.println("Enter new application name");
								ApplicationConfig.setAppName(inputParam.getString());
								System.out.println("Do you want to change the version (Y/N)");
								if(inputParam.getCheckYesNo()){
									System.out.println("Current application version - " + ApplicationConfig.appVersion);
									System.out.println("Enter application version (numeric only)");
									ApplicationConfig.appVersion = inputParam.getFloat();
								}
								System.out.println("Application name is updated to " + ApplicationConfig.appName);
								System.out.println("\n");
								break;
							default:
								System.out.println("You have entered incorrect option");
								System.out.println("\n");
								break;
						}
						break;
					case 0: 
						break;
					default:
						System.out.println("You have entered incorrect option");
						System.out.println("\n");
						break;
				}
				
			} while (option!=0);
			
		} 	catch (IllegalArgumentException ex) {
				System.out.println("\n");
				System.out.println("Illegal Argument Exception Caught: " + ex.getMessage());
		} 	catch (NullPointerException ex) {
				System.out.println("\n");
				System.out.println("Null Pointer Exception Caught: " + ex.getMessage());
		}	catch (Exception ex) {
				System.out.println("\n");
				System.out.println("Generic Exception Caught: " + ex.getMessage());
		}	finally	{
			System.out.println("\n");
			System.out.println("Closing program - Bye");
		}
	}
}