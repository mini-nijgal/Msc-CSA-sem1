import support.UserInputs;

class DesktopPC extends Computer{
	private boolean hasDVDWriterEnabled;
	
	public DesktopPC(String AssetType) {
		super(AssetType);
		UserInputs inputParam = new UserInputs();
		System.out.println("DVD Writer (Y/N)");
		setHasDVDWriterEnabled(inputParam.getCheckYesNo());
	}
	
	public void Display(){
		super.Display();
		System.out.println("Has DVDWriter Enabled " + this.isHasDVDWriterEnabled());
	}
	
	public void Edit() {
		super.Edit();
		UserInputs inputParam = new UserInputs();
		System.out.println("Have DVD Writer (Y/N) | Currently Has WebCamera - " + this.isHasDVDWriterEnabled());
		setHasDVDWriterEnabled(inputParam.getCheckYesNo());
	}
	
	public boolean isHasDVDWriterEnabled() {
		return hasDVDWriterEnabled;
	}
	public void setHasDVDWriterEnabled(boolean hasDVDWriterEnabled) {
		this.hasDVDWriterEnabled = hasDVDWriterEnabled;
	}
}