import support.UserInputs;

public class Laptop extends Computer{
	private float laptopDisplaySize;
	private boolean laptopHasWebCamera;
	
	public Laptop(String AssetType) {
		super(AssetType);
		UserInputs inputParam = new UserInputs();
		System.out.println("Enter Display Size");
		setLaptopDisplaySize(inputParam.getFloat());
		System.out.println("Has WebCamera (Y/N)");
		setLaptopHasWebCamera(inputParam.getCheckYesNo());
	}
	
	public void Display(){
		super.Display();
		System.out.println("Display Size : " + this.getLaptopDisplaySize());
		System.out.println("Has WebCamera : " + this.isLaptopHasWebCamera());
	}
	
	public void Edit() {
		super.Edit();
		UserInputs inputParam = new UserInputs();
		System.out.println("Enter Display Size | Current Display Size - " + this.getLaptopDisplaySize());
		setLaptopDisplaySize(inputParam.getFloat());
		System.out.println("Has WebCamera (Y/N) | Currently Has WebCamera - " + this.isLaptopHasWebCamera());
		setLaptopHasWebCamera(inputParam.getCheckYesNo());
	}
	
	public float getLaptopDisplaySize() {
		return laptopDisplaySize;
	}
	public void setLaptopDisplaySize(float laptopDisplaySize) {
		this.laptopDisplaySize = laptopDisplaySize;
	}
	public boolean isLaptopHasWebCamera() {
		return laptopHasWebCamera;
	}
	public void setLaptopHasWebCamera(boolean laptopHasWebCamera) {
		this.laptopHasWebCamera = laptopHasWebCamera;
	}
}