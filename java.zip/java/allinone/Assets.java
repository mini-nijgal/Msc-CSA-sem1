import java.time.LocalDate;
import support.CoreAssetFunctions;
import support.UserInputs;

public class Assets extends CoreAssetFunctions {//inheriting abstract class Company
	private String assetType;
	private String assetName;
	private long assetSlNo;
	private String assetVendor;
	private LocalDate assetPurchaseDate;
	static long staticAssetSlNo;
	
	static { 
		//static block
		staticAssetSlNo = 1000;// static variable
	}
	
	public Assets(String assetType) {
		//constructor call for entering details while creating asset object
		CreateCompanyAsset(assetType);
	}
	
	public void CreateCompanyAsset(String assetType) {
		assetSlNo = ++staticAssetSlNo;
		UserInputs inputParam = new UserInputs();
		System.out.println("Enter Name");
		this.setAssetName(inputParam.getString());
		System.out.println("Enter Vendor");
		this.setAssetVendor(inputParam.getString());
		this.setAssetType(assetType);
		this.setAssetPurchaseDate(java.time.LocalDate.now());
	}

	public void Display(){
		System.out.println("\n");
		System.out.println("Sl. No : " + this.getAssetSlNo());
		System.out.println("Name : " + this.assetName);
		System.out.println("Vendor : " + this.assetVendor);
		System.out.println("Type : " + this.assetType);
		System.out.println("Purchase Date : " + this.assetPurchaseDate);
	}
	public void Edit(){
		UserInputs inputParam = new UserInputs();
		System.out.println("Enter Name | Current Name - " + this.getAssetName());
		this.setAssetName(inputParam.getString());
		System.out.println("Enter Vendor | Current Vendor Name - " + this.getAssetVendor());
		this.setAssetVendor(inputParam.getString());
	}		
	
	public String getAssetType() {
		return assetType;
	}
	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public long getAssetSlNo() {
		return assetSlNo;
	}
	public void setAssetSlNo(long assetSlNo) {
		this.assetSlNo = assetSlNo;
	}
	public String getAssetVendor() {
		return assetVendor;
	}
	public void setAssetVendor(String assetVendor) {
		this.assetVendor = assetVendor;
	}
	public LocalDate getAssetPurchaseDate() {
		return assetPurchaseDate;
	}
	public void setAssetPurchaseDate(LocalDate localDate) {
		this.assetPurchaseDate = localDate;
	}
}