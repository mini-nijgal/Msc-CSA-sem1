package support;

public class CustomExceptions extends Exception{
	private static final long serialVersionUID = 1L;//unique identifier for Serializable classes

	public CustomExceptions(String message) {
		//CustomException to display exception
		System.out.println("Exeption Caught :" + message);
	}
}
