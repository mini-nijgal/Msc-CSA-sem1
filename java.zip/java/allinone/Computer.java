import support.UserInputs;

public class Computer extends Assets {
	private int storageCapacity;
	private int RAM;
	private String processorModel;
	private String processorGeneration;
	private String operatingSystem;
	private boolean isHardened;
	
	public Computer(String AssetType)	{
		super(AssetType);
		UserInputs inputParam = new UserInputs();
		System.out.println("Enter Storage Capacity in GB");
		this.setStorageCapacity(inputParam.getIntegerWithCannotBeZeroValidation());
		System.out.println("Enter RAM in GB");
		this.setRAM(inputParam.getIntegerWithCannotBeZeroValidation());
		System.out.println("Enter Processor Model (Intel/AMD)");
		this.setProcessorModel(inputParam.getString());
		System.out.println("Enter Processor Generation");
		this.setProcessorGeneration(inputParam.getString());
		System.out.println("Enter Operation System (Windows 10/Windows 8.1/Windows 8/Windows Server 2016 R2/Fredora/Kali/Redhat");
		this.setOperatingSystem(inputParam.getString());
		System.out.println("Is computer hardended with company policy (Y/N)");
		this.setHardened(inputParam.getCheckYesNo());
		
	}
	
	public void Display(){
		super.Display();
		System.out.println("Storage Capacity : " + this.getStorageCapacity());
		System.out.println("RAM : " + this.getRAM());
		System.out.println("Processor Model : " + this.getProcessorModel());
		System.out.println("Processor Generation : " + this.getProcessorGeneration());
		System.out.println("Operating System : " + this.getOperatingSystem());
		System.out.println("Is Hardened : " + this.isHardened());
	}
	
	public void Edit() {
		super.Edit();
		UserInputs inputParam = new UserInputs();
		System.out.println("Enter Storage Capacity in GB | Current Capacity - " + this.getStorageCapacity());
		this.setStorageCapacity(inputParam.getInteger());
		System.out.println("Enter RAM in GB | Current RAM - " + this.getRAM());
		this.setRAM(inputParam.getInteger());
		System.out.println("Enter Processor Model (Intel/AMD) | Current Processor Model - " + this.getProcessorModel());
		this.setProcessorModel(inputParam.getString());
		System.out.println("Enter Processor Generation | Current Processor Generation - " + this.getProcessorGeneration());
		this.setProcessorGeneration(inputParam.getString());
		System.out.println("Enter Operation System | Current Operating System - " + this.getOperatingSystem());
		this.setOperatingSystem(inputParam.getString());
		System.out.println("Is computer hardended with company policy (Y/N) | Current Status - " + this.isHardened());
		this.setHardened(inputParam.getCheckYesNo());
	}
	

	public int getStorageCapacity() {
		return storageCapacity;
	}
	public void setStorageCapacity(int storageCapacity) {
		this.storageCapacity = storageCapacity;
	}
	public int getRAM() {
		return RAM;
	}
	public void setRAM(int RAM) {
		this.RAM = RAM;
	}
	public String getProcessorModel() {
		return processorModel;
	}
	public void setProcessorModel(String processorModel) {
		this.processorModel = processorModel;
	}
	public String getProcessorGeneration() {
		return processorGeneration;
	}
	public void setProcessorGeneration(String processorGeneration) {
		this.processorGeneration = processorGeneration;
	}
	public String getOperatingSystem() {
		return operatingSystem;
	}
	public void setOperatingSystem(String operatingSystem) {
		this.operatingSystem = operatingSystem;
	}
	public boolean isHardened() {
		return isHardened;
	}
	public void setHardened(boolean b) {
		this.isHardened = b;
	}
}