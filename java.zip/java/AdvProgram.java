import java.util.Scanner;
class Adverstisement {
private int adverstisement_id;
private String client_name;
private String start_date;
static int adv_no;
	 

static {
	 	 //static block
	 	 adv_no = 0;// static variable
}
	 

public Adverstisement(String client_name, String start_date) {
	 	 //constructor call for entering details while creating asset object
	 	 adverstisement_id = ++adv_no;
	 	 Scanner sc1 = new Scanner(System.in);
	 	 System.out.println("\n\n\nEnter Client Name");
	 	 this.setClientName(sc1.nextLine());
	 	 System.out.println("Enter Start Date");
	 	 this.setStartDate(sc1.nextLine());
}
public void display(){
	 	 System.out.println("\n");
	 	 System.out.println("Adverstisement ID : " + this.getAdvertisementId());
	 	 System.out.println("Client Name : " + this.getClientName());
	 	 System.out.println("Start Date : " + this.getStartDate());
}	 

	 

public String getClientName() {
	 	 return client_name;
}
public void setClientName(String client_name) {
	 	 this.client_name = client_name;
}
public String getStartDate() {
	 	 return start_date;
}
public void setStartDate(String start_date) {
	 	 this.start_date = start_date;
}
public long getAdvertisementId() {
	 	 return adverstisement_id;
}
public void setAdvertisementId(int adverstisement_id) {
	 	 this.adverstisement_id = adverstisement_id;
}
}
class Commercial_Ad extends Adverstisement {
private String size_of_ad;
private String price_of_ad;
	 

public Commercial_Ad(String client_name, String start_date) {
	 	 super(client_name, start_date);
	 	 Scanner sCm = new Scanner(System.in);
	 	 System.out.println("Enter Size of Ad");
	 	 this.setSizeOfAd(sCm.nextLine());
	 	 System.out.println("Enter Price of Ad");
	 	 this.setPriceOfAd(sCm.nextLine());
}
	 

public void display(){
	 	 super.display();
	 	 System.out.println("Size of Ad: " + this.getSizeOfAd());
	 	 System.out.println("Price of Ad : " + this.getPriceOfAd());
}
	 

public String getSizeOfAd() {
	 	 return size_of_ad;
}
public void setSizeOfAd(String size_of_ad) {
	 	 this.size_of_ad = size_of_ad;
}
public String getPriceOfAd() {
	 	 return price_of_ad;
}
public void setPriceOfAd(String price_of_ad) {
	 	 this.price_of_ad = price_of_ad;
}
}
class Free_Ad extends Adverstisement {
private String free_ad_time_duration;
	 

public Free_Ad(String client_name, String start_date) {
	 	 super(client_name, start_date);
	 	 Scanner sCm = new Scanner(System.in);
	 	 System.out.println("Enter Free Ad Time Duration");
	 	 this.setFreeAdTimeDuration(sCm.nextLine());
}
	 

public void display(){
	 	 super.display();
	 	 System.out.println("Free Time Duration of Ad: " + this.getFreeAdTimeDuration());
}
	 

public String getFreeAdTimeDuration() {
	 	 return free_ad_time_duration;
}
public void setFreeAdTimeDuration(String free_ad_time_duration) {
	 	 this.free_ad_time_duration = free_ad_time_duration;
}
}
public class AdvProgram {
	 

public static void main(String[] args) {
	 	 Scanner sc = new Scanner(System.in);
	 	 Commercial_Ad[] commAds = new Commercial_Ad[1];
	 	 Free_Ad[] freeAds = new Free_Ad[1];
	 	 try {
	 	 	 int option = 0;
	 	 	 do {
	 	 	 	 System.out.println("\n\n\n\n\n************ Welcome To ABC Advertisement Manager ************ ");
	 	 	 	 System.out.println("\n1. Create Commercial Ad");
				 System.out.println("2. Create Free Ad");
				 System.out.println("3. Display Commercial Ads with cost above 5000");
	 	 	 	 System.out.println("4. Display Free Ads with duration above 2 months");
	 	 	 	 System.out.println("\nEnter choice:");
				 option = sc.nextInt();
			switch(option){
	 	 	 	 	 case 1:
	 	 	 	 	 	 System.out.println("Enter number of Commercial Ads");
	 	 	 	 	 	 commAds = new Commercial_Ad[sc.nextInt()];
						 for (int i = 0; i < commAds.length; i++){
	 	 	 	 	 	 commAds[i] = new
						Commercial_Ad("client_name", "start_date");
						commAds[i].display();
	 	 	 	 	 	 }
						break;
	 	 	 	 	 case 2:
	 	 	 	 	 	 System.out.println("Enter number of Free Ads");
freeAds = new Free_Ad[sc.nextInt()];
for (int i = 0; i < freeAds.length; i++){
	 	 	 	 	 	 	 freeAds[i] = new Free_Ad("client_name",
"start_date");
freeAds[i].display();
	 	 	 	 	 	 }
break;
	 	 	 	 	 case 3:
	 	 	 	 	 	 for (int i = 0; i < commAds.length; i++){
	 	 	 	 	 	 	 if (Integer.parseInt(commAds[i].getPriceOfAd())
> 5000){
	 	 	 	 	 	 	 	 commAds[i].display();
	 	 	 	 	 	 	 }
	 	 	 	 	 	 }
break;
	 	 	 	 	 case 4:
	 	 	 	 	 	 for (int i = 0; i < freeAds.length; i++){
	 	 	 	 	 	 	 if
(Integer.parseInt(freeAds[i].getFreeAdTimeDuration()) > 2){
	 	 	 	 	 	 	 	 freeAds[i].display();
	 	 	 	 	 	 	 }
	 	 	 	 	 	 }
break;
	 	 	 	 	 case 0: 
	 	 	 	 	 	 System.out.println("Closing program");
break;
	 	 	 	 	 default:
	 	 	 	 	 	 System.out.println("You have entered incorrect
option");
	 	 	 	 	 	 System.out.println("\n");
break;
	 	 	 	 }
				

	 	 	 } while (option!=0);
			

	 	 } catch (Exception ex) {
	 	 	 System.out.println(ex.getMessage());
	 	 }
	 	 finally {
	 	 	 sc.close();
	 	 }
}
}