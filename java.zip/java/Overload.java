import java.io.*;
import java.util.Scanner;
  class Customer
{
	private String  custName;
	private  byte custAge;
	private long accNo;
	private char gender;
        private short minBal;
	private float bal;

	private long custId;
     boolean pan;

public Customer()
{
  custName="ss";
   custAge=0;
   accNo=-1;
   gender='F';
   minBal=0;
   bal=0;
   custId=0;
   
}
public void read() throws IOException
	{
		InputStreamReader isr=new    						InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		Scanner scan=new Scanner(System.in);
      	System.out.println("Enter the customer name");
		custName=br.readLine();
		System.out.println("Enter the customer age");
		custAge=Byte.parseByte(br.readLine());
		System.out.println("Enter the customer account number");
		accNo=Long.parseLong(br.readLine());
  	        System.out.println("Enter the Minimum Baance");
                minBal=Short.parseShort(br.readLine());
        	System.out.println("Enter the Balance Amount");
               // bal=Float.valueOf(br.readLine()).floatValue();
                bal=Float.parseFloat(br.readLine());
		 //bal=scan.nextFloat();
       	  	System.out.println("Enter the customer Gender");
		gender=(char)br.read();
System.out.println("Do you have Pan Card");
pan=Boolean.parseBoolean(br.readLine());
      }
	public void disp()
	{
		System.out.println("Customer Name ="+custName);
		System.out.println("Customer Age ="+custAge);
		System.out.println("Customer Account Number ="+accNo);
		System.out.println("Customer Gender="+gender);

		System.out.println("Customer Balance="+bal);
		System.out.println("\n");
		
		System.out.println("Pan Card="+pan);

    // pan=Boolean.parseBoolean(br.readLine()); 
       //  boolean bn = n.nextBoolean();

	}
	

public void custDisplayMinBal(short b)
{
	if(minBal<b)
	{
   	disp();
	}
}



public void custDisplayMinBal(short b, char g)
{

if(minBal<b && gender==g)
{

disp();
}
}

}
public class Overload
{
	public static void main(String args[]) throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	    boolean ch=true;
		byte res,res1,b1;
short minbal;
char gen;
		//Customer ob1=new Customer();
//ob1.disp();
		Customer obj[]= new Customer[3];
		
  //     short bal=Short.parseShort(args[0]);
		while(ch)
		{
			System.out.println("1. read data");
			System.out.println("2. Display data");
                System.out.println("3. MinBalance or minbalance and gender");
			System.out.println("4. Exit");
			System.out.println("Enter your choice");
			res=Byte.parseByte(br.readLine());
			switch(res)
			{
				case 1:
		               for(byte i=0;i<2;i++)
					   {
						   obj[i]=new Customer();
						   obj[i].read();
					   }	
						break;					   
                case 2 :
						for(byte i=0;i<2;i++)
					   {
						   obj[i].disp();
					   }
					   

						break;	


                 case 3: 
{

 System.out.println("11. MinBalance ");
 System.out.println("22.minbalance and gender");
System.out.println("Enter your choice");
			res1=Byte.parseByte(br.readLine());
switch(res1)
{
case 11:
System.out.println("enter minimum balance");
 minbal=Short.parseShort(br.readLine());


                         for(byte i=0;i<2;i++)
{
				obj[i].custDisplayMinBal(minbal);
}
break;	
case 22:
System.out.println("enter minimum balance");
 minbal=Short.parseShort(br.readLine());
System.out.println("enter gender");
gen=(char)br.read();
for(byte i=0;i<2;i++)
		{				   														obj[i].custDisplayMinBal(minbal,gen);
					   }

					   

						break;	
}
}
break;

				   
				case 4 :
         
        
        			       ch=false;
		 
				      
			  }//end of outer switch
			
			
		}// end of while
			
			
			
		}// end of main
		
}//end of class

		
