
import java.util.Scanner;
import java.time.LocalDate;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

class UserInputs {
	public int getInteger() {
		//returns int value
		Scanner scanValidate = new Scanner(System.in);
		String param = scanValidate.nextLine();
		if(!param.matches("\\d+")){
			System.out.println("Invalid Number, Enter Numeric Value Only");
			return getInteger();
		}
		return Integer.parseInt(param);
	}
	
	public long getLong() {
		//returns long value
		Scanner scanValidate = new Scanner(System.in);
		String param = scanValidate.nextLine();
		if(!param.matches("\\d+")){
			System.out.println("Invalid Number, Enter Numeric Value Only");
			return getLong();
		}
		return Long.parseLong(param);
	}

	public float getFloat() {
		//returns float value
		Scanner scanValidate = new Scanner(System.in);
		String param = scanValidate.nextLine();
		if(!param.matches("[+-]?[0-9]+(\\.[0-9]+)?([Ee][+-]?[0-9]+)?")){
			System.out.println("Invalid Number, Enter Numeric Value Only");
			return getFloat();
		}
		return Float.parseFloat(param);
	}
	
	public String getString(){
		//Returns String value and Only Number Alphabets and space is allowed
		Scanner scanValidate = new Scanner(System.in);
		String param = scanValidate.nextLine();
		if(!param.matches("[A-Za-z0-9\\s]+")){
			System.out.println("Invalid String, Enter only number, alphabets and space");
			return getString();
		}
		return param;
	}
	
	public boolean getCheckYesNo(){
		//returns boolean value based on y and n parameters
		Scanner scanValidate = new Scanner(System.in);
		String param = scanValidate.nextLine();
		boolean isAcceptable = false;
		if(param.toLowerCase().charAt(0)=='y'){
			isAcceptable = true;
		} else if(param.toLowerCase().charAt(0)=='n'){
			isAcceptable = false;
		} else {
			System.out.println("Invalid String, Enter Y or N only");
			return getCheckYesNo();
		}
		return isAcceptable;
	}
}

abstract class Company{
	//abstract class
	abstract void CreateCompanyAsset(String assetType);
	abstract void Display();
	abstract void Edit();
	
}

class Assets extends Company {
	private String assetType;
	private String assetName;
	private long assetSlNo;
	private String assetVendor;
	private LocalDate assetPurchaseDate;
	static long staticAssetSlNo;
	
	static { 
		//static block
		staticAssetSlNo = 1000;// static variable
	}
	
	public Assets(String assetType){
		//constructor call for entering details while creating asset object
		CreateCompanyAsset(assetType);
	}
	
	public void CreateCompanyAsset(String assetType){
		assetSlNo = ++staticAssetSlNo;
		UserInputs inputParam = new UserInputs();
		System.out.println("Enter Name");
		setAssetName(inputParam.getString());
		System.out.println("Enter Vendor");
		setAssetVendor(inputParam.getString());
		setAssetType(assetType);
		setAssetPurchaseDate(java.time.LocalDate.now());
	}

	public void Display(){
		System.out.println("\n");
		System.out.println("Sl. No : " + getAssetSlNo());
		System.out.println("Name : " + getAssetName());
		System.out.println("Vendor : " + assetVendor);
		System.out.println("Type : " + assetType);
		System.out.println("Purchase Date : " + assetPurchaseDate);
	}
	public void Edit() {
		UserInputs inputParam = new UserInputs();
		System.out.println("Enter Name | Current Name - " + getAssetName());
		this.setAssetName(inputParam.getString());
		System.out.println("Enter Vendor | Current Vendor Name - " + getAssetVendor());
		this.setAssetVendor(inputParam.getString());
	}		
	
	public String getAssetType() {
		return assetType;
	}
	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public long getAssetSlNo() {
		return assetSlNo;
	}
	public void setAssetSlNo(long assetSlNo) {
		this.assetSlNo = assetSlNo;
	}
	public String getAssetVendor() {
		return assetVendor;
	}
	public void setAssetVendor(String assetVendor) {
		this.assetVendor = assetVendor;
	}
	public LocalDate getAssetPurchaseDate() {
		return assetPurchaseDate;
	}
	public void setAssetPurchaseDate(LocalDate localDate) {
		this.assetPurchaseDate = localDate;
	}
}

class Computer extends Assets {
	private int storageCapacity;
	private int RAM;
	private String processorModel;
	private String processorGeneration;
	private String operatingSystem;
	private boolean isHardened;
	public Computer(String AssetType) 	{
		super(AssetType);
		UserInputs inputParam = new UserInputs();
		System.out.println("Enter Storage Capacity in GB");
		this.setStorageCapacity(inputParam.getInteger());
		System.out.println("Enter RAM in GB");
		this.setRAM(inputParam.getInteger());
		System.out.println("Enter Processor Model (Intel/AMD)");
		this.setProcessorModel(inputParam.getString());
		System.out.println("Enter Processor Generation");
		this.setProcessorGeneration(inputParam.getString());
		System.out.println("Enter Operation System (Windows 10/Windows 8.1/Windows 8/Windows Server 2016 R2/Fredora/Kali/Redhat");
		this.setOperatingSystem(inputParam.getString());
		System.out.println("Is computer hardended with company policy (Y/N)");
		this.setHardened(inputParam.getCheckYesNo());
	}
	public void Display(){
		super.Display();
		System.out.println("Storage Capacity : " + this.getStorageCapacity());
		System.out.println("RAM : " + this.getRAM());
		System.out.println("Processor Model : " + this.getProcessorModel());
		System.out.println("Processor Generation : " + this.getProcessorGeneration());
		System.out.println("Operating System : " + this.getOperatingSystem());
		System.out.println("Is Hardened : " + this.isHardened());
	}
	public void Edit() {
		super.Edit();
		UserInputs inputParam = new UserInputs();
		System.out.println("Enter Storage Capacity in GB | Current Capacity - " + this.getStorageCapacity());
		this.setStorageCapacity(inputParam.getInteger());
		System.out.println("Enter RAM in GB | Current RAM - " + this.getRAM());
		this.setRAM(inputParam.getInteger());
		System.out.println("Enter Processor Model (Intel/AMD) | Current Processor Model - " + this.getProcessorModel());
		this.setProcessorModel(inputParam.getString());
		System.out.println("Enter Processor Generation | Current Processor Generation - " + this.getProcessorGeneration());
		this.setProcessorGeneration(inputParam.getString());
		System.out.println("Enter Operation System | Current Operating System - " + this.getOperatingSystem());
		this.setOperatingSystem(inputParam.getString());
		System.out.println("Is computer hardended with company policy (Y/N) | Current Status - " + this.isHardened());
		this.setHardened(inputParam.getCheckYesNo());
	}
	
	public int getStorageCapacity() {
		return storageCapacity;
	}
	public void setStorageCapacity(int storageCapacity) {
		this.storageCapacity = storageCapacity;
	}
	public int getRAM() {
		return RAM;
	}
	public void setRAM(int RAM) {
		this.RAM = RAM;
	}
	public String getProcessorModel() {
		return processorModel;
	}
	public void setProcessorModel(String processorModel) {
		this.processorModel = processorModel;
	}
	public String getProcessorGeneration() {
		return processorGeneration;
	}
	public void setProcessorGeneration(String processorGeneration) {
		this.processorGeneration = processorGeneration;
	}
	public String getOperatingSystem() {
		return operatingSystem;
	}
	public void setOperatingSystem(String operatingSystem) {
		this.operatingSystem = operatingSystem;
	}
	public boolean isHardened() {
		return isHardened;
	}
	public void setHardened(boolean b) {
		this.isHardened = b;
	}
}

class Laptop extends Computer{
	private float laptopDisplaySize;
	private boolean laptopHasWebCamera;
	
	public Laptop(String AssetType) {
		super(AssetType);
		UserInputs inputParam = new UserInputs();
		System.out.println("Enter Display Size");
		setLaptopDisplaySize(inputParam.getFloat());
		System.out.println("Has WebCamera (Y/N)");
		setLaptopHasWebCamera(inputParam.getCheckYesNo());
	}
	public void Display(){
		super.Display();
		System.out.println("Display Size : " + this.getLaptopDisplaySize());
		System.out.println("Has WebCamera : " + this.isLaptopHasWebCamera());
	}
	public void Edit() {
		super.Edit();
		UserInputs inputParam = new UserInputs();
		System.out.println("Enter Display Size | Current Display Size - " + this.getLaptopDisplaySize());
		setLaptopDisplaySize(inputParam.getFloat());
		System.out.println("Has WebCamera (Y/N) | Currently Has WebCamera - " + this.isLaptopHasWebCamera());
		setLaptopHasWebCamera(inputParam.getCheckYesNo());
	}
	public float getLaptopDisplaySize() {
		return laptopDisplaySize;
	}
	public void setLaptopDisplaySize(float laptopDisplaySize) {
		this.laptopDisplaySize = laptopDisplaySize;
	}
	public boolean isLaptopHasWebCamera() {
		return laptopHasWebCamera;
	}
	public void setLaptopHasWebCamera(boolean laptopHasWebCamera) {
		this.laptopHasWebCamera = laptopHasWebCamera;
	}
}

class DesktopPC extends Computer{
	private boolean hasDVDWriterEnabled;
	
	public DesktopPC(String AssetType) {
		super(AssetType);
		UserInputs inputParam = new UserInputs();
		System.out.println("DVD Writer (Y/N)");
		setHasDVDWriterEnabled(inputParam.getCheckYesNo());
	}
	public void Display(){
		super.Display();
		System.out.println("Has DVDWriter Enabled " + this.isHasDVDWriterEnabled());
	}
	public void Edit() {
		super.Edit();
		UserInputs inputParam = new UserInputs();
		System.out.println("Have DVD Writer (Y/N) | Currently Has WebCamera - " + this.isHasDVDWriterEnabled());
		setHasDVDWriterEnabled(inputParam.getCheckYesNo());
	}
	public boolean isHasDVDWriterEnabled() {
		return hasDVDWriterEnabled;
	}
	public void setHasDVDWriterEnabled(boolean hasDVDWriterEnabled) {
		this.hasDVDWriterEnabled = hasDVDWriterEnabled;
	}
}


public class ResourceManager {
	static class ApplicationConfig { //static class
		protected static String appName = "Test Software"; //static variable
		protected static Float appVersion = 1.0f; 
		public static void setAppName(String newAppName) { //static method
			//static block
			appName = newAppName;
		}
		public static void appInfo(){//static method
			//static block
			System.out.println("***** Applicaiton Configuration *****");
			System.out.println("Applicaiton Name - " + appName);
			System.out.println("Application Version - " + appVersion.toString());
			System.out.println("\n");
		}
	}
	public static void main(String[] args){
		try {
			int option = 0;
			Long assetNumber;
			UserInputs inputParam = new UserInputs();
			// ConcurrentHashMap is thread-safe variant of ArrayList
			Map<Long, Laptop> laptopAssets = new ConcurrentHashMap<Long, Laptop>();//to store asset details
			Map<Long, DesktopPC> computerAsssets = new ConcurrentHashMap<Long, DesktopPC>();//to store asset details
			Map<Long, String> objectType = new ConcurrentHashMap<Long, String>(); //to store object type based and cast it
			do {
				System.out.println("************ " + ApplicationConfig.appName + " ************ ");
				System.out.println("1. Asset Management");
				System.out.println("2. Application Config");
				System.out.println("0. Exit");
				System.out.println("Enter the below operations");
				option = inputParam.getInteger();
				switch(option){ 
					case 1:
						System.out.println(" ***** Asset*****");
						System.out.println("1. Create New Asset");
						System.out.println("2. View Asset");
						System.out.println("3. Remove Asset");
						System.out.println("4. Edit Asset");
						System.out.println("5. View All Assets");
						switch(inputParam.getInteger()) {
							case 1: 
								System.out.println("### Create new asset ###");
								System.out.println("Enter Asset Catagory");
								System.out.println("1. Laptop");
								System.out.println("2. Desktop PC");
								switch(inputParam.getInteger()) {
									case 1:
										System.out.println("Enter Laptop Details");
										Laptop laptopObj = new Laptop("Laptop");
										laptopAssets.put(Laptop.staticAssetSlNo, laptopObj);
										objectType.put(Laptop.staticAssetSlNo, "Laptop");
										System.out.println("New Laptop registed with Asset ID : " + Laptop.staticAssetSlNo);
										break;
									case 2:
										System.out.println("Enter Desktop Details");
										DesktopPC desktopObj = new DesktopPC("Desktop PC");
										computerAsssets.put(DesktopPC.staticAssetSlNo, desktopObj);
										objectType.put(DesktopPC.staticAssetSlNo, "DesktopPC");
										System.out.println("New Desktop registed with Asset ID : " + DesktopPC.staticAssetSlNo);
										break;
									}
								
								System.out.println("\n");
								break;
							case 2: 
								System.out.println("### View Asset ###");
								System.out.println("Enter asset number");
								assetNumber = new Long(inputParam.getLong());
								if(objectType.containsKey(assetNumber)){
									switch (objectType.get(assetNumber)){
									case "Laptop":
										System.out.println("Printing laptop");
										laptopAssets.get(assetNumber).Display();
										break;
									case "DesktopPC":
										System.out.println("Printing Desktop");
										computerAsssets.get(assetNumber).Display();
										break;
									}
								}
								else {
									System.out.println("Invalid Asset ID");
								}
								System.out.println("\n");
								break;
							case 3: 
								System.out.println("### Remove Asset ###");
								System.out.println("Enter asset number");
								assetNumber = new Long(inputParam.getLong());
								if(objectType.containsKey(assetNumber)){
									switch (objectType.get(assetNumber)){
									case "Laptop":
										laptopAssets.remove(assetNumber);
										break;
									case "DesktopPC":
										computerAsssets.remove(assetNumber);
										break;
									}
									objectType.remove(assetNumber);	
									System.out.println("Asset ID " + assetNumber.toString() + " was removed");
								}
								else {
									System.out.println("Invalid Asset ID");
								}
								System.out.println("\n");
								break;
							case 4: 
								System.out.println("### Edit Asset ###");
								System.out.println("Enter asset number");
								assetNumber = new Long(inputParam.getLong());
								if(objectType.containsKey(assetNumber)){
									switch (objectType.get(assetNumber)){
									case "Laptop":
										laptopAssets.get(assetNumber).Edit();
										break;
									case "DesktopPC":
										computerAsssets.get(assetNumber).Edit();
										break;
									}
								}
								else {
									System.out.println("Invalid Asset ID");
								}
								System.out.println("\n");
								break;

							case 5: 
								System.out.println("### View All Assets ###");
								if(laptopAssets.size() == 0 && computerAsssets.size()==0){
									System.out.println("No Assets exists");
								} else {
									if(laptopAssets.size()>0) {
										System.out.println("Printing Laptops");
										laptopAssets.forEach((k,v) -> v.Display());
									}
									if(computerAsssets.size()>0){
										System.out.println("Printing Computers");
										computerAsssets.forEach((k,v) -> v.Display());
									}
								}
								System.out.println("\n");
								break;
							}
						break;
					case 2: 
						System.out.println(" ***** Application Configuration *****");
						System.out.println("1. View Application Configruation");
						System.out.println("2. Reset Application Configuration");
						System.out.println("0. Return to Main Menu");
						switch(inputParam.getInteger()) {
							case 1:
								ApplicationConfig.appInfo();
								break;
							case 2: 
								System.out.println("***** Reset Application Name *****");
								System.out.println("Enter new application name");
								ApplicationConfig.setAppName(inputParam.getString());
								System.out.println("Do you want to change the version (Y/N)");
								if(inputParam.getCheckYesNo()){
									System.out.println("Current application version - " + ApplicationConfig.appVersion);
									System.out.println("Enter application version (numeric only)");
									ApplicationConfig.appVersion = inputParam.getFloat();
								}
								System.out.println("Application name is updated to " + ApplicationConfig.appName);
								System.out.println("\n");
								break;
							default:
								System.out.println("You have entered incorrect option");
								System.out.println("\n");
								break;
						}
						break;
					case 0: 
						break;
					default:
						System.out.println("You have entered incorrect option");
						System.out.println("\n");
						break;
				}
				
			} while (option!=0);
			
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		finally{
			System.out.println("Closing program");
		}
	}
}