package pack1;
public class Employee
{
private int empId;
private String name;
public Employee()
{
empId=200;
name="sss";
}
public void disp()
{
System.out.println(empId);
System.out.println(name);
}
}
