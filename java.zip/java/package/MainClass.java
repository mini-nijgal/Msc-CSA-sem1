import pack1.Employee;
import pack1.Manager;

public class MainClass
{
    public static void main(String args [])
    {
        Manager m = new Manager();
        m.disp();
        Employee e = new Employee();
        e.disp();
        System.out.println("Hello");
    }
}