package pack1;
public class Manager extends Employee
{
private String deptName;
public Manager()
{
super();
deptName="Computer Science";
}
public void disp()
{
//System.out.println(empId);
//System.out.println(name);
super.disp();
System.out.println(deptName);
}
}