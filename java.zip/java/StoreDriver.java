import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StoreDriver {

    public static void main(String[] args) throws FileNotFoundException {

        //1. Declare variables managerCount, salesAssociateCount of type integer and initialize them to 0.
        int managerCount = 0;
        int salesAssociateCount = 0;

        //2. Declare & initialize an object for PrintWriter class and use the file name "outputFile.txt" to write the corresponding data
        PrintWriter pwd = new PrintWriter(new File("outputFile.txt"));
        //3. Declare and initialize a scanner object "scanner" to read from the file "inputFile.txt"
        Scanner sc = new Scanner(new File("inputFile.txt"));
        //4. Declare and initialize a List object of type Manager as "managerList", and initialize the object as an ArrayList. 
        List<Manager> managerList = new ArrayList<Manager>();
        //5. Declare and initialize a List object of type SalesAssociate as "salesAssociateList", and initialize the object as an ArrayList. 
        List<SalesAssociate> SalesAssociateList = new ArrayList<SalesAssociate>();
        //6. While inputFile.txt has more data(While loop starts here) {
        while (sc.hasNext()) {

            String employeeType = sc.nextLine();
            String storeDetails = sc.nextLine();
            String empName = sc.nextLine();
            double basePay = sc.nextDouble();
            double numberOfHoursWorked = sc.nextDouble();
            double hourlyRate = sc.nextDouble();

            //   Read in the data, and store them to the respective variables such as,
            //   employeeType, storeDetails, empName variables of type String.
            //   basePay, numberOfHoursWorked and hourlyRate as type double
            // 7. If the employee type in the inputFile is "Manager" , then declare variables currentSales, CurrentStoreSales of type double
            //    and read the data. 
            if (employeeType.equals("Manager")) {
                double currentSales = sc.nextDouble();
                double CurrentStoreSales = sc.nextDouble();

             //7a. create an object for Manager named as "manager" 
             //    and initialize the multiple argument constructor with above mentioned variables in (question 6 & 7). 
             //    Then add the manager object to the arrayList of managerList.If the employee type is not manager then 
             //    declare a variable salesRate of type double and scan the element, now create an object for salesAssociate named as "salesAssociate",
             //    initialize the sales associate by invoking the constructor of SalesAssociate class with above mentioned variables (question 6 & 7). 
             //    Then add the salesAssociate object to the arrayList of salesAssociateList
                Manager manager = new Manager(CurrentStoreSales, currentSales, numberOfHoursWorked,
                        hourlyRate, storeDetails, basePay, empName);
                String str = sc.nextLine();
                managerList.add(manager);

            } else {
                double salesRate = sc.nextDouble();
                SalesAssociate salesAssociate = new SalesAssociate(salesRate, numberOfHoursWorked, hourlyRate, storeDetails, empName, basePay);
                SalesAssociateList.add(salesAssociate);
                if (sc.hasNext()) {
                    sc.nextLine();
                }

            }

        }

        // While Loop ends here
        //8. Print the size of the managerList to the console and outputfile. See the sample output for sample formatting
        System.out.println("******************************************************");
        System.out.println("Number of employees working as MANAGER are: " + managerList.size());
        System.out.println("******************************************************");
        pwd.println("******************************************************");
        pwd.println("Number of employees working as MANAGER are: " + managerList.size());
        pwd.println("******************************************************");
        //9. Use an enhanced for loop and iterate through managerList which is of type Manager and use "manager" as variable.
        //   Increment the count of the managerCount by one every time loop is started. Now test the toString() method of manager class. Also write this output to 
        //   the console & outputFile. Test the salesPercentByManager of manager class and write the output to both console and output file.
        //   Test the calculatePay(), calculateRemainingStoreRevenue(double), and checkPromotionEligibility() method of manager class and write the output to both console and output file. Do the required String formatting by seeing the sample output

        for (Manager manager : managerList) {
            managerCount++;
            System.out.println(managerCount + ". Manager Details:");
            System.out.println(manager);
            pwd.println(managerCount + ". Manager Details:");
            pwd.println(manager);
            System.out.println("Percentage of sales done: " + String.format("%.2f", manager.salesPercentByManager()) + "%");
            pwd.println("Percentage of sales done: " + String.format("%.2f", manager.salesPercentByManager()) + "%");
            System.out.println("Gross Payment: $" + String.format("%.1f", manager.calculatePay()));
            pwd.println("Gross Payment: $" + String.format("%.1f", manager.calculatePay()));
            System.out.println("Remaining store revenue: $" + manager.calculateRemainingStoreRevenue(manager.getTotalStoreSales()));
            pwd.println("Remaining store revenue: $" + manager.calculateRemainingStoreRevenue(manager.getTotalStoreSales()));

            System.out.print("Is " + manager.getEmployeeName() + " eligible for promotion? ");
            if (manager.checkPromotionEligibility() == true) {
                System.out.println("Yes, he is \n");
            } else {
                System.out.println("No, he needs to work harder\n");
            }

        }

        //   For Loop ends here
        //10.Print the size of the salesAssociateList to the console and outputfile. See the sample output for sample formatting
        System.out.println("******************************************************");
        System.out.println("Number of employees working as SALES ASSOCIATES are: " + SalesAssociateList.size());
        System.out.println("******************************************************");
        pwd.println("******************************************************");
        pwd.println("Number of employees working as SALES ASSOCIATES are: " + SalesAssociateList.size());
        pwd.println("******************************************************");

        //11. Use a enhanced for loop and iterate through salesAssociateList which is of type SalesAssociate and use "salesAssociate" as variable.
        //   Increment the count of the salesAssociateCount by one every time loop is started. Now test the toString() method of SalesAssociate class. Also write this output to 
        //   the console & outputFile. 
        //   Test the calculatePay(), calculateCommission(), and checkPromotionEligibility() method of salesAssociate class and write the output to both console and output file. Do the required String formatting by seeing the sample output        
        for (SalesAssociate salesAssociate : SalesAssociateList) {
            salesAssociateCount++;
            System.out.println(salesAssociateCount + ". Sales Associate Details:");
            System.out.println(salesAssociate);
            pwd.println(salesAssociate);
            System.out.println("Total commission: $" + salesAssociate.calculateCommission());
            System.out.println("Gross Payment: $" + salesAssociate.calculatePay());

            pwd.println("Total commission: $" + salesAssociate.calculateCommission());
            pwd.println("Gross Payment: $" + salesAssociate.calculatePay());
            System.out.print("Is " + salesAssociate.getEmployeeName() + " eligible for promotion? ");
            if (salesAssociate.checkPromotionEligibility() == true) {
                System.out.println("Yes, he/she is eligible\n");
            } else {
                System.out.println("No, he/she needs to work harder\n");
            }

        }
        pwd.close();
        //   For loop ends after this
    }
}


 interface Employee {

    
    /**
     * This method Calculates the pay of the employee.
     *
     * @return- This method returns double Pay of the Employee.
     */
    double calculatePay();

    /**
     * This method Checks if the employee should be awarded with a promotion.
     *
     * @return- This method returns boolean the eligibility status for
     * promotion. for an employee.
     */
    boolean checkPromotionEligibility();

}
/**
 * This is the AbstractStoreEmployee abstract class file implements Employee and
 * Sore.
  */
abstract class AbstractStoreEmployee implements Employee, Store {

    private double basePay;
    String employeeName;
    private double hourlyRate;
    private double numberOfHoursWorked;
    private String storeDetails;

    /**
     * This is an argument constructor which initializes all the instance
     * variables
     *
     * @param numberOfHoursWorked - The parameter Number of hours worked is
     * passed.
     * @param hourlyRate - The parameter Hourly rate of the Employee in dollars
     * is passed.
     * @param storeDetails - The parameter Details of the Store is passed.
     * @param basePay - The parameter Base pay of the Employee in dollars is
     * passed.
     * @param employeeName - The parameter Full name of the Employee is passed.
     */
    public AbstractStoreEmployee(double numberOfHoursWorked, double hourlyRate, String storeDetails,
            double basePay, String employeeName) {
        this.numberOfHoursWorked = numberOfHoursWorked;
        this.hourlyRate = hourlyRate;
        this.storeDetails = storeDetails;
        this.basePay = basePay;
        this.employeeName = employeeName;
    }

    /**
     * Calculates the total commission of the employee.
     *
     * @return- This method returns the total commission
     */
    @Override
    public double calculateCommission() {
        return 0;
    }

    /**
     * Calculates pay
     *
     * @return- This method returns calculatePay.
     */
    @Override
    public abstract double calculatePay();

    /**
     * Calculates the store revenue and returns the store revenue
     *
     * @param storeSales- The Parameter storeSales is passed.
     * @return- This method returns Store revenue
     */
    @Override
    public double calculateRemainingStoreRevenue(double storeSales) {
        double employeePay = calculatePay();
        double storeRevenue = 0;

        storeRevenue = storeSales * (1 - TAX) - employeePay;

        if (storeSales > 255000) {
            storeRevenue = (1 - 0.05) * storeRevenue;
        } else if (storeSales > 155000 && storeSales <= 255000) {
            storeRevenue = (1 - 0.03) * storeRevenue;
        } else {
            storeRevenue = (1 - 0.01) * storeRevenue;
        }
        return storeRevenue;
    }

    /**
     * Checks if the employee should be awarded with promotion
     *
     * @return - This method returns the eligibility status for promotion for an
     * employee.
     */
    @Override
    public abstract boolean checkPromotionEligibility();

    /**
     * Returns the base pay of the employee
     *
     * @return This method returns Base pay amount.
     */
    public double getBasePay() {
        return basePay;
    }

    /**
     * Sets the Base pay
     *
     * @param basePay - The Parameter Base pay value is passed.
     */
    public void setBasePay(double basePay) {
        this.basePay = basePay;
    }

    /**
     * Returns the Name of the Employee
     *
     * @return- This method returns String Employee name.
     */
    public String getEmployeeName() {
        return employeeName;
    }

    /**
     * Sets the Employee name
     *
     * @param employeeName Name of the Employee
     */
    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    /**
     * Returns hourly rate for the employee
     *
     * @return - This method returns Hourly rate.
     */
    public double getHourlyRate() {
        return hourlyRate;
    }

    /**
     * Sets the hourly rate
     *
     * @param hourlyRate - The parameter Hourly rate is passed.
     */
    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    /**
     * Returns number of hours worked hours
     *
     * @return- This method returns number of hours worked
     */
    public double getNumberOfHoursWorked() {
        return numberOfHoursWorked;
    }

    /**
     * Sets the number of hours worked
     *
     * @param numberOfHoursWorked - The parameter number of hours worked is
     * passed.
     */
    public void setNumberOfHoursWorked(double numberOfHoursWorked) {
        this.numberOfHoursWorked = numberOfHoursWorked;
    }

    /**
     * Sets the Store Details
     *
     * @param storeDetails- The parameter Details of the Store is passed.
     */
    public void setStoreDetails(String storeDetails) {
        this.storeDetails = storeDetails;
    }

    /**
     * Returns private variable are separated by one space.
     *
     * @return- This returns string representation of Employee and Store
     * details.
     */
    @Override
    public String toString() {
        return "Store Details: " + storeDetails + "\nEmployee Name: " + employeeName
                + "\nBase Pay: $" + basePay + "\nNumber of Hours worked: " + numberOfHoursWorked + "hrs"
                + "\nPayment Rate per hour: $" + hourlyRate + "/hr\n";
    }

}

/**
 * This is the Manager class file extends AbstractStoreEmployee.
  */
class Manager extends AbstractStoreEmployee {

    private double bonusRate;
    private double salesDone;
    private double totalStoreSales;

    /**
     * This is an Argument constructor which Initializes all the Instance
     * Variables. bonusRate is initialized with 0. Also Calls a Super class
     * Constructor to initialize numberOfHoursWorked, hourlyRate, storeDetails,
     * basePay, name variables.
     *
     * @param totalStoreSales - The parameter Total Sales in the Store is
     * passed.
     * @param salesDone - The parameterTotal Sales taken place in the store is
     * passed.
     * @param numberOfHoursWorked - The parameter Number of Hours worked by the
     * Manager is passed.
     * @param hourlyRate - The parameter Hourly rate for the Manager is passed.
     * @param storeDetails - The parameterDetails of the Store is passed.
     * @param basePay - The parameter Base Pay Rate is passed.
     * @param name - The parameter Name of the Manager is passed.
     */
    public Manager(double totalStoreSales, double salesDone, double numberOfHoursWorked,
            double hourlyRate, String storeDetails, double basePay, String name) {
        super(numberOfHoursWorked, hourlyRate, storeDetails, basePay, name);
        this.bonusRate = bonusRate;
        this.salesDone = salesDone;
        this.totalStoreSales = totalStoreSales;
        this.bonusRate = 0;
    }

    /**
     * Returns the total Pay for a Manager.
     *
     * @return- This method returns total pay for a manager.
     */
    @Override
    public double calculatePay() {

        if (salesDone > 25000) {
            bonusRate = 15.00;
        } else if (salesDone > 5000 && salesDone <= 25000) {
            bonusRate = 10.00;
        } else {
            bonusRate = 1;
        }

        return (super.getNumberOfHoursWorked() * super.getHourlyRate()
                + super.getBasePay()) * (1 + bonusRate / 100);

    }

    /**
     * Checks if the employee should be awarded with a promotion.
     *
     * @return - This method returns the eligibility status for promotion for an
     * employee.
     */
    @Override
    public boolean checkPromotionEligibility() {

        if (calculatePay() > 50000.0) {

            return true;
        } else {

            return false;
        }
    }

    /**
     * Returns the bonus rate for a manager in percentage.
     *
     * @return - This method returns double Bonus Rate in percentage
     */
    public double getBonusRate() {
        return bonusRate / 100;
    }

    /**
     * Returns total sales performed by the manager in dollars.
     *
     * @return- This method returns Sales done by the manager
     */
    public double getSalesDone() {
        return salesDone;
    }

    /**
     * Returns the total store sales in dollars
     *
     * @return- This method returns Total sales in the store
     */
    public double getTotalStoreSales() {
        return totalStoreSales;
    }

    /**
     * Returns the sales percentage of the manager.
     *
     * @return - This method returns Sales Percentage for the Manager
     */
    public double salesPercentByManager() {
        return (salesDone / totalStoreSales) * 100;
    }

    /**
     * Returns the bonus rate for a manager in percentage.
     *
     * @param bonusRate- The parameter Bonus Rate in percentage is passed.
     */
    public void setBonusRate(double bonusRate) {
        this.bonusRate = bonusRate;
    }

    /**
     * Sets total sales.
     *
     * @param salesDone - The parameter Sales Done is passed.
     */
    public void setSalesDone(double salesDone) {
        this.salesDone = salesDone;
    }

    /**
     * Returns the total store sales in dollars
     *
     * @param totalStoreSales - The parameter Total sales in the store is
     * passed.
     */
    public void setTotalStoreSales(double totalStoreSales) {
        this.totalStoreSales = totalStoreSales;
    }

    /**
     * Returns the String representation of stores sales made by manager and
     * total sales in store.
     *
     * @return - This method returns a String representation of total store
     * sales and sales done.
     */
    @Override
    public String toString() {
        return super.toString() + "Total Sales in store: $" + totalStoreSales
                + "\nSales done: $" + salesDone;
    }

}

/**
 * This is the SalesAssociate class file extends AbstractStoreEmployee class
 * file.
 */
 class SalesAssociate extends AbstractStoreEmployee {

    private final double salesRate;

    /**
     * This is a argument constructor which Initializes variable salesRate and
     * need to call its super class to initialize other variables
     *
     * @param salesRate - The parameter Percentage of sales done by a
     * SalesAssociate is passed.
     * @param numberOfHoursWorked - The parameter Number of hours worked is
     * passed.
     * @param hourlyRate - The parameter Hourly Rate is passed.
     * @param storeDetails - The parameter Details of the Store is passed.
     * @param associateName - The parameter Name of the Sales Associate is
     * passed.
     * @param basePay - The parameter Base pay is passed.
     */
    public SalesAssociate(double salesRate, double numberOfHoursWorked, double hourlyRate,
            String storeDetails, String associateName, double basePay) {
        super(numberOfHoursWorked, hourlyRate, storeDetails, basePay, associateName);
        this.salesRate = salesRate;
    }

    /**
     * Returns the total commission of the Sales Associate in dollars.
     *
     * @return - This method returns the commission in dollars.
     */
    @Override
    public double calculateCommission() {
        if (getSalesRate() > 30) {
            return super.getBasePay() * COMMISSION_RATE;
        } else {
            return 0.0;
        }
    }

    /**
     * Returns calculated Pay of the Sales Associate. The calculated pay is the
     * sum of basePay, commission and the product of number of hours worked and
     * hourly rate.
     *
     * @return - This method returns Payment of the Sales Associate.
     */
    @Override
    public double calculatePay() {
        return super.getBasePay() + calculateCommission() + 
                (super.getNumberOfHoursWorked() * super.getHourlyRate());
    }

    /**
     * Checks if the employee should be awarded with a promotion.
     *
     * @return - This method returns boolean the eligibility status for
     * promotion for an employee.
     */
    @Override
    public boolean checkPromotionEligibility() {
        if (calculatePay() > 25000.0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Percentage of sales done by a SalesAssociate.
     *
     * @return- This method returns double Percentage of sales done by a
     * SalesAssociate.
     */
    public double getSalesRate() {
        return salesRate * 100;
    }

    /**
     * Returns the String representation of Sales. Append Super Class toString()
     * along with the Sales Rate.
     *
     * @return - This method returns a String representation of Sales and
     * Employee details.
     */
    @Override
    public String toString() {
        return super.toString() + "Sales Rate: " + getSalesRate() + "%";
    }

}

/**
 * This is the Store interface file.
 */
 interface Store {

    /**
     * It is a constant field value.
     */
    static final double COMMISSION_RATE = 0.10;
    

    /**
     * It is a constant field value.
     */
    static final double TAX = 0.14;

    /**
     *
     * @return 
     * @return- This method returns the calculateCommission.
     */
    public double calculateCommission();

    /**
     *
     * @param storeSales - The parameter storeSales is passed.
     * @return - This method returns the remaining store revenue.
     */
    public double calculateRemainingStoreRevenue(double storeSales);

}



